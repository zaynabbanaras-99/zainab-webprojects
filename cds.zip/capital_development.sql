-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 30, 2025 at 07:06 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `capital_development`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `booking_id` int(11) NOT NULL,
  `customer_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `service_type` varchar(100) DEFAULT NULL,
  `preferred_date` date DEFAULT NULL,
  `message` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`booking_id`, `customer_name`, `email`, `phone`, `address`, `service_type`, `preferred_date`, `message`, `created_at`) VALUES
(6, 'zaynab banaras', 'zaynabbanaras123@icloud.com', '330 9238696', 'westrifshf', 'Pest Bird Control', '2023-09-09', 'hjshf', '2025-08-06 14:11:46'),
(7, 'amna', 'banaraskhan@gmail.com', '0330 9238696', 'g15/2 street 18 house 256', 'Warehouse Hygienization', '2025-10-02', 'plz come to see us', '2025-10-06 08:23:37');

-- --------------------------------------------------------

--
-- Table structure for table `contact`
--

CREATE TABLE `contact` (
  `contact_id` int(10) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `message` mediumtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `contact`
--

INSERT INTO `contact` (`contact_id`, `name`, `email`, `message`) VALUES
(9, 'zaynab bnaras khan', 'zaynabbanaras123@icloud.com', 'i want a pest treatment'),
(10, 'zainab', 'ismaeel@gmail.com', 'najdiw\\maxavks;n\\'),
(11, 'zainab', 'ismaeel@gmail.com', 'najdiw\\maxavks;n\\');

-- --------------------------------------------------------

--
-- Table structure for table `faq`
--

CREATE TABLE `faq` (
  `faq_id` int(10) NOT NULL,
  `question` mediumtext NOT NULL,
  `answer` mediumtext NOT NULL,
  `faq_dt` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `faq`
--

INSERT INTO `faq` (`faq_id`, `question`, `answer`, `faq_dt`) VALUES
(1, 'what is the best feature in it?', 'customization on vast levels', '2024-09-08 20:09:30'),
(2, 'how much variations are possible?\r\n', 'colors, styles, sizes, fabrics', '2024-09-08 20:26:05'),
(3, 'what\\\'s new?', 'Winter Essentials!', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `fumigation_services`
--

CREATE TABLE `fumigation_services` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `service_name` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `fumigation_services`
--

INSERT INTO `fumigation_services` (`id`, `category`, `service_name`, `description`, `created_at`) VALUES
(1, 'General Pest Control', 'General Insect Pest Control', 'Cockroaches, flies, mosquitoes etc. for domestic & commercial properties', '2025-08-08 12:06:21'),
(2, 'Termite Treatment', 'Pre and Post Anti Termite Treatment', 'Available for domestic & commercial properties, both pre-construction and post-construction', '2025-08-08 12:06:21'),
(3, 'Pest Bird Control', 'Pest Bird Control', 'Control and prevention of pest birds for domestic & commercial properties', '2025-08-08 12:06:21'),
(4, 'Rodent Control', 'Rat Control', 'Latest techniques for operation control service and maintenance service', '2025-08-08 12:06:21'),
(5, 'Water Tank Cleaning', 'Water Tank Cleaning & Treatment', 'Underground & overhead water tank cleaning services', '2025-08-08 12:06:21'),
(6, 'Warehouse Hygiene', 'Warehouse Hygienization', 'Integrated pest management with pest control services', '2025-08-08 12:06:21'),
(7, 'IPM', 'Integrated Pest Management', 'Survey of object area to evaluate problems and provide solutions for betterment', '2025-08-08 12:06:21'),
(8, 'Training', 'Pest Management Training', 'Awareness and control training for public health pests/vectors', '2025-08-08 12:06:21'),
(9, 'Fumigation', 'Fumigation of Cargo in Warehouse', 'Under tarpaulin covers or sealing entire warehouse', '2025-08-08 12:06:21'),
(10, 'Fumigation', 'Fumigation of Cargo in Containers', 'Checking containers prior stuffing & fumigation after stuffing', '2025-08-08 12:06:21'),
(11, 'Fumigation', 'Fumigation of Cargo in Ship Holds', 'After completion of loading of cargo', '2025-08-08 12:06:21'),
(12, 'Fumigation', 'Fumigation of Empty Cargo Holds', 'Prior to loading in ship holds', '2025-08-08 12:06:21'),
(13, 'Fumigation', 'Fumigation of Antiques and Precious Materials', 'In in-house fumigation chamber', '2025-08-08 12:06:21'),
(14, 'Training', 'Fumigation of Commodities Training', 'Solutions to control insect pests from cargo for export', '2025-08-08 12:06:21'),
(15, 'Disinfectant', 'Poultry and Cattle Farm Disinfectant Spray', 'Control of microbial pests and related disease control', '2025-08-08 12:06:21');

-- --------------------------------------------------------

--
-- Table structure for table `hygiene_material_supplier`
--

CREATE TABLE `hygiene_material_supplier` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `hygiene_material_supplier`
--

INSERT INTO `hygiene_material_supplier` (`id`, `title`, `description`) VALUES
(1, 'Disposable Surgical Cap (White/Green)', 'High-quality disposable surgical caps for hygiene.'),
(2, 'Disposable Face Mask (White/Green)', 'Breathable disposable face masks for safety.'),
(3, 'Disposable Beard Mask (White/Green)', 'Comfortable beard masks to maintain cleanliness.'),
(4, 'Disposable Shoe Covers', 'Durable disposable shoe covers for contamination control.'),
(5, 'Disposable Gloves', 'Latex/nitrile disposable gloves for hygiene.'),
(6, 'Apron', 'Protective disposable aprons for multiple uses.');

-- --------------------------------------------------------

--
-- Table structure for table `orders_line`
--

CREATE TABLE `orders_line` (
  `order_line_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `product_id` int(10) NOT NULL,
  `quantity` int(50) NOT NULL,
  `size` varchar(10) NOT NULL,
  `style` varchar(50) NOT NULL,
  `color` varchar(50) NOT NULL,
  `fabric` varchar(50) NOT NULL,
  `price` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders_line`
--

INSERT INTO `orders_line` (`order_line_id`, `order_id`, `product_id`, `quantity`, `size`, `style`, `color`, `fabric`, `price`) VALUES
(46, 84, 7, 1, 'large', 'short sleeves', 'green', 'cotton', 990),
(48, 85, 6, 1, ' small', 'kaprii', 'black', 'cotton lawn', 789),
(49, 85, 7, 1, '', 'hallf sleeves', 'white', 'Dhanak', 990),
(51, 86, 6, 1, '', 'long shirt', 'yellow', '', 789),
(52, 86, 7, 1, '', '', 'orange', '', 990),
(54, 87, 6, 1, '', '', 'ice blue', '', 789),
(55, 87, 7, 1, '', '', '', '', 990),
(57, 88, 6, 1, '', '', '', '', 789),
(58, 88, 7, 1, '', '', '', '', 990),
(60, 89, 6, 1, '', '', '', '', 789),
(61, 89, 7, 1, '', '', '', '', 990),
(105, 105, 6, 1, 'medium', 'neckline', 'blue', 'linnen', 789),
(115, 114, 6, 1, '', 'stylish jeans', 'grey', '', 8034);

-- --------------------------------------------------------

--
-- Table structure for table `order_placed`
--

CREATE TABLE `order_placed` (
  `order_id` int(10) NOT NULL,
  `user_email` varchar(100) NOT NULL,
  `full_name` varchar(50) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `payment_method_used` varchar(50) NOT NULL,
  `shipping_method` varchar(100) NOT NULL,
  `shipping_address` varchar(50) NOT NULL,
  `order_type` varchar(50) NOT NULL,
  `order_status` varchar(50) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `order_placed`
--

INSERT INTO `order_placed` (`order_id`, `user_email`, `full_name`, `phone_no`, `payment_method_used`, `shipping_method`, `shipping_address`, `order_type`, `order_status`, `order_date`) VALUES
(5, '0', 'kainat', 2147483647, 'Credit Card', '', 'PO KHAUR', '', '', '0000-00-00 00:00:00'),
(6, '0', 'kainat', 2147483647, 'Credit Card', '', 'PO KHAUR', '', '', '0000-00-00 00:00:00'),
(7, '0', 'kainat', 2147483647, 'Credit Card', '', 'PO KHAUR', '', '', '0000-00-00 00:00:00'),
(11, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(12, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(13, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(14, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(15, '0', 'hadia', 46567876, 'Credit Card', '', 'PO ferozwali', '', '', '0000-00-00 00:00:00'),
(16, '0', 'hadia', 46567876, 'Credit Card', '', 'PO ferozwali', '', '', '0000-00-00 00:00:00'),
(17, '0', 'hadia', 46567876, 'Credit Card', '', 'PO ferozwali', '', '', '0000-00-00 00:00:00'),
(18, '0', 'hadia', 46567876, 'Credit Card', '', 'PO ferozwali', '', '', '0000-00-00 00:00:00'),
(19, '0', 'hadia', 46567876, 'Credit Card', '', 'PO ferozwali', '', '', '0000-00-00 00:00:00'),
(20, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(21, '0', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(22, '0', 'kainat khan', 261979906, 'COD', '', 'PO KHAUR, ATTOCK', '', '', '0000-00-00 00:00:00'),
(23, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(24, 'kainat@gmail.com', 'kainat khan', 261979906, 'COD', '', 'PO KHAUR,ATTOCK', '', '', '0000-00-00 00:00:00'),
(25, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(26, 'kainat@gmail.com', 'kainat khan', 262979906, 'Credit Card', 'Express shipping', 'PO KHAUR, ATTOCKK', '', '', '0000-00-00 00:00:00'),
(27, 'kainat@gmail.com', 'kainat khan', 262979906, 'Credit Card', 'Express shipping', 'PO KHAUR, ATTOCKK', '', '', '0000-00-00 00:00:00'),
(28, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(29, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(30, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(31, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(32, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(33, '', '', 0, '', '', '', '', '', '0000-00-00 00:00:00'),
(34, 'hania@gamil.com', 'hania khan', 261979906, 'Credit Card', 'Overnight shipping', 'PO KHAUR, FEROZWALII', '', '', '0000-00-00 00:00:00'),
(35, '', '', 0, '', '', '', '', '', '2024-08-27 06:56:07'),
(36, 'kainat@gmail.com', 'kainat khan', 261979906, 'Credit Card', 'Express shipping', 'PO KHAUR, ATTOCK', '', '', '2024-08-27 06:56:37'),
(37, 'kainat@gmail.com', 'kainat khan', 261979906, 'Credit Card', 'Express shipping', 'PO KHAUR, ATTOCK', '', '', '2024-08-27 07:10:36'),
(38, 'ddf@gmaiil.com', 'hadia', 123456, 'COD', 'standard shipping', 'PO KHAUR', '', '', '2024-08-27 07:11:40'),
(39, '', '', 0, '', '', '', '', '', '2024-08-27 10:06:17'),
(40, '', '', 0, '', '', '', '', '', '2024-08-27 10:06:24'),
(41, '', '', 0, '', '', '', '', '', '2024-08-27 10:08:24'),
(42, '', '', 0, '', '', '', '', '', '2024-08-27 10:09:18'),
(43, '', '', 0, '', '', '', '', '', '2024-08-27 10:17:23'),
(44, 'kainat@gmail.com', 'kainat khan', 261979906, 'Credit Card', 'Overnight shipping', 'PO KHAUR ATTOCK', '', '', '2024-08-27 10:17:53'),
(45, '', '', 0, '', '', '', '', '', '2024-08-27 14:45:54'),
(46, 'tanzeela@gmail.com', 'tanzeela', 128965, 'Credit Card', 'Overnight shipping', 'PO KAMRIYAL', '', '', '2024-08-27 14:46:28'),
(47, 'tanzeela@gmail.com', 'tanzeela', 128965, 'Credit Card', 'Overnight shipping', 'PO KAMRIYAL', '', '', '2024-08-27 14:59:00'),
(48, '', '', 0, '', '', '', '', '', '2024-08-27 15:01:21'),
(49, '', '', 0, '', '', '', '', '', '2024-08-27 15:36:23'),
(50, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 15:36:43'),
(51, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 15:48:45'),
(52, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 15:52:40'),
(53, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 15:53:14'),
(54, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 15:53:43'),
(55, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 16:18:56'),
(56, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 16:20:45'),
(57, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 16:22:12'),
(58, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'standard', 'hdgtesrfgcf', '', '', '2024-08-27 17:01:24'),
(59, '', '', 0, '', '', '', '', '', '2024-08-27 17:02:09'),
(60, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:02:30'),
(61, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:04:07'),
(62, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:07:16'),
(63, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:09:46'),
(64, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:15:39'),
(65, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:22:19'),
(66, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:36:37'),
(67, 'kainat@gmail.com', 'kainat khan', 2147483647, 'credit_card', 'express', 'sjfhiewf', '', '', '2024-08-27 17:40:35'),
(68, '', '', 0, '', '', '', '', '', '2024-08-29 06:48:08'),
(69, 'kainat@gmail.com', 'kainat khan', 2147483647, 'cash_on_delivery', 'express', 'PO KHAUR', '', '', '2024-08-29 06:48:41'),
(70, '', '', 0, '', '', '', '', '', '2024-08-29 06:54:01'),
(71, '', '', 0, '', '', '', '', '', '2024-08-29 06:58:23'),
(72, '', '', 0, '', '', '', '', '', '2024-08-29 06:58:48'),
(73, '', '', 0, '', '', '', '', '', '2024-08-29 07:01:50'),
(74, '', '', 0, '', '', '', '', '', '2024-08-29 07:10:05'),
(75, '', '', 0, '', '', '', '', '', '2024-08-29 07:13:47'),
(76, '', '', 0, '', '', '', '', '', '2024-08-29 14:57:05'),
(77, '', '', 0, '', '', '', '', '', '2024-08-29 14:59:17'),
(78, '', '', 0, '', '', '', '', '', '2024-08-29 15:18:14'),
(79, '', '', 0, '', '', '', '', '', '2024-08-29 15:19:16'),
(80, 'kainat@gmail.com', 'kainat khan', 2147483647, 'cash_on_delivery', 'express', 'PO KHAUR', '', '', '2024-08-29 15:19:38'),
(81, 'kainat@gmail.com', 'kainat khan', 2147483647, 'cash_on_delivery', 'express', 'PO KHAUR', '', '', '2024-08-29 15:23:31'),
(82, '', '', 0, '', '', '', '', '', '2024-09-03 07:34:50'),
(83, '', '', 0, '', '', '', '', '', '2024-09-03 16:20:00'),
(84, '', '', 0, '', '', '', '', '', '2024-09-07 15:33:00'),
(85, '', '', 0, '', '', '', '', '', '2024-09-07 15:38:22'),
(86, '', '', 0, '', '', '', '', '', '2024-09-07 15:50:03'),
(87, '', '', 0, '', '', '', '', '', '2024-09-07 15:51:26'),
(88, '', '', 0, '', '', '', '', '', '2024-09-07 15:52:30'),
(89, '', '', 0, '', '', '', '', '', '2024-09-07 15:55:07'),
(90, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:28:46'),
(91, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:29:06'),
(92, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:08:18'),
(93, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:08:06'),
(94, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:29:19'),
(95, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:07:43'),
(96, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:07:31'),
(97, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Direct purchase', '', '2024-10-19 15:07:20'),
(98, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:07:03'),
(99, 'kainat@gmail.com', 'kainat khan', 123456, 'credit_card', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:06:52'),
(100, 'kainat@gmail.com', 'kainat khan', 123456, 'cash_on_delivery', 'express', 'PO khaur, attock', 'Direct purchase', '', '2024-10-19 15:06:35'),
(101, 'kainat@gmail.com', 'kainat khan', 123456, 'cash_on_delivery', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 15:01:21'),
(102, 'kainat@gmail.com', 'kainat khan', 123456, 'cash_on_delivery', 'express', 'PO khaur, attock', 'Direct purchase', '', '2024-10-19 15:01:53'),
(103, 'kainat@gmail.com', 'kainat khan', 123456, 'cash_on_delivery', 'express', 'PO khaur, attock', 'Direct purchase', '', '2024-10-19 15:01:10'),
(104, 'kainat@gmail.com', 'kainat khan', 123456, 'cash_on_delivery', 'express', 'PO khaur, attock', 'Customized dress', '', '2024-10-19 14:59:41'),
(105, 'ddf@gmail.com', 'tanzeela', 2147483647, 'credit_card', 'express', 'PO KHAUR', 'Direct purchase', 'delivered', '2024-11-18 13:31:44'),
(106, '23october@gmail.com', 'october', 23434243, 'cash_on_delivery', 'express', 'PO final project project', 'Customized dress', '', '2024-10-19 14:59:17'),
(107, 'hania@gmail.com', 'hania khan', 6780986, 'credit_card', 'standard', 'PO hgyjgg', 'Direct purchase', '', '2024-10-17 15:33:35'),
(108, 'hadia123@gmail.com', 'hadia', 647, 'credit_card', 'standard', 'PO ferozwaliii', 'Customized dress', 'pending', '2024-10-20 15:57:57'),
(109, 'ddf@gmail.com', 'tanzeela', 454657673, 'credit_card', 'standard', 'PO KHKJJGJYG', 'Direct purchase', 'delivered', '2024-11-18 13:28:50'),
(110, 'kainat@gmail.com', 'kainatt', 0, 'hmgh', 'bkhk', 'hnjfg', 'Customized dress', 'pending', '2024-11-26 15:15:19'),
(111, 'kainat@gmail.com', 'kainatt', 0, 'hmgh', 'bkhk', 'hnjfg', 'Customized dress', 'delivered', '2024-11-26 15:15:28'),
(112, 'kainat@gmail.com', 'hadia', 0, 'hmgh', 'bkhk', 'hnjfg', 'Direct purchase', 'pending', '2024-10-20 15:57:14'),
(113, 'khattak@gmail.com', 'khattak', 89098768, 'cash_on_delivery', 'express', 'PO KHAUR', 'Customized dress', 'pending', '2024-10-20 15:57:08'),
(114, 'kainat@gmail.com', 'uiuouiu', 7890, 'cash_on_delivery', 'express', 'khaur', 'Customized dress', '', '2024-10-25 06:27:40');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category` varchar(100) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image_url` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category`, `name`, `description`, `image_url`) VALUES
(1, 'termite', 'Termicol', 'Highly effective termiticide for professional pest control treatment, ensuring long-term protection.', 'agenda EC25.jpg'),
(2, 'termite', 'Agenda EC25', 'Premium quality termite control solution used for pre and post-construction anti-termite treatments.', 'images/termites/agenda_ec25.jpg'),
(3, 'termite', 'Termicure', 'Advanced termite bait system designed for quick elimination of colonies with minimal environmental impact.', 'images/termites/termicure.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `product_category`
--

CREATE TABLE `product_category` (
  `category_id` int(10) NOT NULL,
  `category_name` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `product_images`
--

CREATE TABLE `product_images` (
  `pro_img_id` int(10) NOT NULL,
  `pro_img_name` text NOT NULL,
  `product_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_title` varchar(255) NOT NULL,
  `service_description` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_title`, `service_description`, `created_at`) VALUES
(1, 'General Insect Pest Control', 'Cockroaches, Flies, Mosquitoes etc. Available for Domestic & Commercial Properties.', '2025-08-05 17:28:43'),
(2, 'Pre and Post Anti-Termite Treatment', 'Free Survey Available. Pre-Construction & Post-Construction Treatment for Domestic & Commercial Properties.', '2025-08-05 17:28:43'),
(3, 'Pest Bird Control', 'Available for Domestic & Commercial Properties.', '2025-08-05 17:28:43'),
(4, 'Rat Control', 'With Latest Techniques - Operation Control & Maintenance Services.', '2025-08-05 17:28:43'),
(5, 'Water Tank Cleaning & Treatment', 'Cleaning and Treatment of Underground & Overhead Water Tanks.', '2025-08-05 17:28:43'),
(6, 'Warehouse Hygienization', 'Integrated Pest Management (IPM) with Pest Control Services.', '2025-08-05 17:28:43'),
(7, 'Integrated Pest Management (IPM)', 'Survey of the object area to evaluate the pest problem and provide a tailored solution for long-term results.', '2025-08-05 17:28:43'),
(8, 'Pest Management Training', 'A complete solution for the awareness and control of public health pests and vectors.', '2025-08-05 17:28:43');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `user_id` int(10) NOT NULL,
  `user_name` varchar(100) NOT NULL,
  `user_email` varchar(150) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_type` varchar(20) NOT NULL,
  `account_creation_dt` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_email`, `user_password`, `user_type`, `account_creation_dt`) VALUES
(1, 'kainatt', 'kainat@gmail.com', 'BSCS2003', 'user', '2024-11-28 02:33:39'),
(2, 'kainatkhan', 'kainatkhan@gmail.com', 'BSCS2024', 'user', '2024-11-16 14:31:18'),
(3, 'khattak', 'khattak@gmail.com', 'bscs2003', 'Admin', '2024-09-11 07:40:39'),
(4, 'tanzeela', 'ddf@gmail.com', '282002', 'user', '2024-11-18 13:27:06'),
(5, 'kt', 'kt@gmail.com', 'kt123456', 'user', '2024-10-20 15:56:14'),
(6, '', 'tehreem@hotmail.com', '123456', '', '2024-10-25 06:36:28');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` varchar(50) DEFAULT 'user',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `role` enum('user','admin') DEFAULT 'user',
  `status` enum('pending','approved','denied') DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `email`, `password`, `user_type`, `created_at`, `role`, `status`) VALUES
(1, 'amna', 'zaynabbanaras@gmail.com', '$2y$10$RYlAht3J0s8rSfcZVk4NPOAb85sPWJuPZvpOo4lG8Jj1ZJ0/rhe8e', 'user', '2025-07-29 10:12:07', 'user', 'pending'),
(2, 'ismaeel', 'maheen@gmail.com', '$2y$10$cJJWPls6v0GsYMGP18vSWeDfpPX2Ssquwd8xc1fYyGFRPvlvAI7lK', 'user', '2025-10-26 08:54:46', 'user', 'pending'),
(3, 'ali is ali', 'ismaeel@gmail.com', '$2y$10$DwkYCMm0N0anA8nb/Wg84epouFZw3V1oqkxXVD4fwmMZ3wm.0/LeW', 'user', '2025-10-26 09:08:21', 'user', 'pending'),
(4, 'zaynabbanaras', 'banaraskhan22@gmail.com', '$2y$10$Ne6eQyXnUDtIA8BntswUKehYsxg7YQr3w/mdLSSTOkG1QAH1JBoXG', 'user', '2025-10-28 09:31:11', 'user', 'pending'),
(5, 'zaynabbanaras', 'banaraskhan@gmail.com', '$2y$10$93JRrRJBCqQHQUo1nfsqDuGz4yGtxOzJ42VAaZexyK2TUC.K0XYxW', 'user', '2025-10-28 09:32:00', 'user', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `user_address`
--

CREATE TABLE `user_address` (
  `user_address_id` int(11) NOT NULL,
  `user_email` varchar(150) NOT NULL,
  `is_default` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_address`
--

INSERT INTO `user_address` (`user_address_id`, `user_email`, `is_default`) VALUES
(1, 'kainat@gmail.com', 'PO khaur, attock'),
(2, 'tanzeela@gmail.com', 'PO kamriyal, Attock');

-- --------------------------------------------------------

--
-- Table structure for table `user_feedback`
--

CREATE TABLE `user_feedback` (
  `feedback_id` int(11) NOT NULL,
  `username` varchar(100) NOT NULL,
  `email` varchar(150) NOT NULL,
  `comment` text NOT NULL,
  `date_time` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `user_feedback`
--

INSERT INTO `user_feedback` (`feedback_id`, `username`, `email`, `comment`, `date_time`) VALUES
(1, 'zaynabbanaras', 'zaynabbanaras123@icloud.com', 'it  was a good experience', '2025-10-29 10:40:28');

-- --------------------------------------------------------

--
-- Table structure for table `variation-options`
--

CREATE TABLE `variation-options` (
  `option_id` int(10) NOT NULL,
  `variation_type` varchar(100) NOT NULL,
  `option_image` text NOT NULL,
  `variation_id` int(10) NOT NULL,
  `additional_cost` int(10) NOT NULL,
  `description` varchar(100) NOT NULL,
  `product_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `variation-options`
--

INSERT INTO `variation-options` (`option_id`, `variation_type`, `option_image`, `variation_id`, `additional_cost`, `description`, `product_id`) VALUES
(16, 'grey', '', 2, 1245, 'purplish shirt', 6),
(18, 'stylish jeans', 'jeans.png', 3, 6789, 'beautiful', 6),
(20, 'Elegant kapri', 'purple.png', 3, 345, 'Designer look', 7),
(21, 'medium', '', 4, 890, 'Great size', 7),
(22, 'navy blue', '', 2, 678, 'Attractive', 7);

-- --------------------------------------------------------

--
-- Table structure for table `variations`
--

CREATE TABLE `variations` (
  `variation_id` int(10) NOT NULL,
  `variation_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `variations`
--

INSERT INTO `variations` (`variation_id`, `variation_name`) VALUES
(1, 'Fabrics'),
(2, 'Colors'),
(3, 'Styles'),
(4, 'Sizes');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`booking_id`);

--
-- Indexes for table `contact`
--
ALTER TABLE `contact`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `faq`
--
ALTER TABLE `faq`
  ADD PRIMARY KEY (`faq_id`);

--
-- Indexes for table `fumigation_services`
--
ALTER TABLE `fumigation_services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hygiene_material_supplier`
--
ALTER TABLE `hygiene_material_supplier`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders_line`
--
ALTER TABLE `orders_line`
  ADD PRIMARY KEY (`order_line_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `order_placed`
--
ALTER TABLE `order_placed`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product_category`
--
ALTER TABLE `product_category`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `product_images`
--
ALTER TABLE `product_images`
  ADD PRIMARY KEY (`pro_img_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- Indexes for table `user_address`
--
ALTER TABLE `user_address`
  ADD PRIMARY KEY (`user_address_id`);

--
-- Indexes for table `user_feedback`
--
ALTER TABLE `user_feedback`
  ADD PRIMARY KEY (`feedback_id`);

--
-- Indexes for table `variation-options`
--
ALTER TABLE `variation-options`
  ADD PRIMARY KEY (`option_id`),
  ADD KEY `product_id` (`product_id`),
  ADD KEY `variation_id` (`variation_id`);

--
-- Indexes for table `variations`
--
ALTER TABLE `variations`
  ADD PRIMARY KEY (`variation_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `contact`
--
ALTER TABLE `contact`
  MODIFY `contact_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `faq`
--
ALTER TABLE `faq`
  MODIFY `faq_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `fumigation_services`
--
ALTER TABLE `fumigation_services`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `hygiene_material_supplier`
--
ALTER TABLE `hygiene_material_supplier`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `orders_line`
--
ALTER TABLE `orders_line`
  MODIFY `order_line_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `order_placed`
--
ALTER TABLE `order_placed`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=115;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product_category`
--
ALTER TABLE `product_category`
  MODIFY `category_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `product_images`
--
ALTER TABLE `product_images`
  MODIFY `pro_img_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `user_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user_address`
--
ALTER TABLE `user_address`
  MODIFY `user_address_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `user_feedback`
--
ALTER TABLE `user_feedback`
  MODIFY `feedback_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `variation-options`
--
ALTER TABLE `variation-options`
  MODIFY `option_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `variations`
--
ALTER TABLE `variations`
  MODIFY `variation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `orders_line`
--
ALTER TABLE `orders_line`
  ADD CONSTRAINT `orders_line_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `order_placed` (`order_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `orders_line_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `product_images`
--
ALTER TABLE `product_images`
  ADD CONSTRAINT `product_images_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `variation-options`
--
ALTER TABLE `variation-options`
  ADD CONSTRAINT `variation-options_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `variation-options_ibfk_3` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`variation_id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

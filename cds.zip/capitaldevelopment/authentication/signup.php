<?php
include("../db_con.php");
session_start();
$error_message = "";

// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Sign-Up Logic
if (isset($_POST['signup'])) {
    $username = trim($_POST['username'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');
    $con_password = trim($_POST['con_password'] ?? '');

    $user_type = "user"; // Default user type

    if (empty($username) || empty($email) || empty($password) || empty($con_password)) {
        $error_message = "All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format.";
    } elseif (strlen($password) < 6) {
        $error_message = "Password must be at least 6 characters long.";
    } elseif ($password !== $con_password) {
        $error_message = "Passwords do not match.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        if (!$stmt) {
            die("Prepare failed: " . $conn->error);
        }

        // ✅ Bind parameter here (missing before)
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Email already exists.";
        } else {
            $hashed_password = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO users (username, email, password, user_type) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("ssss", $username, $email, $hashed_password, $user_type);

            if ($stmt->execute()) {
                $_SESSION['user_id'] = $stmt->insert_id;
                $_SESSION['user_name'] = $username;
                $_SESSION['user_type'] = $user_type;

                // ✅ Redirect based on user type
                if ($user_type === 'addicted_person') {
                    header('Location: ../authentication/personalized_dashboard.php');
                } else {
                    header('Location: ../front_end/index.php'); // You can change this
                }
                exit;
            } else {
                $error_message = "Database error: " . $stmt->error;
            }
        }
        $stmt->close();
    }
    $conn->close();
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up - Wellness Journey</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Reset & Base Styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #c9d6ff, #e2e2e2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .container:hover {
            transform: translateY(-3px);
        }

        .form-container h3 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 26px;
            color: #333;
        }

        .form-container input {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 12px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .form-container input:focus {
            border-color: #6a82fb;
            box-shadow: 0 0 5px rgba(106, 130, 251, 0.5);
            outline: none;
        }

        .form-container button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, #667eea, #764ba2);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s ease;
        }

        .form-container button:hover {
            background: linear-gradient(to right, #5a67d8, #6b46c1);
        }

        .form-container p {
            text-align: center;
            margin-top: 18px;
            font-size: 14px;
            color: #555;
        }

        .form-container a {
            color: #6a82fb;
            font-weight: bold;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: #e74c3c;
            background: #fdecea;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 10px;
            font-size: 14px;
            margin-bottom: 15px;
            text-align: center;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h3>Create an Account</h3>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="text" name="username" placeholder="Full Name" required>
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>
                <input type="password" name="con_password" placeholder="Confirm Password" required>

                <?php if ($error_message): ?>
                    <div class="error-message"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <button type="submit" name="signup">Sign Up</button>
            </form>
            <p>Already have an account? <a href="signin.php">Sign In</a></p>
        </div>
    </div>
</body>
</html>



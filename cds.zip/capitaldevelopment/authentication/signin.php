<?php
include("../db_con.php");
session_start();
$error_message = "";

if (isset($_POST['signin'])) {
    $email = isset($_POST['email']) ? trim($_POST['email']) : '';
    $password = isset($_POST['password']) ? trim($_POST['password']) : '';

    if (empty($email) || empty($password)) {
        $error_message = "Both fields are required.";
    } else {
        $stmt = $conn->prepare("SELECT id, username, password, user_type FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $stmt->bind_result($user_id, $username, $hashed_password, $user_type);
            $stmt->fetch();

            if (password_verify($password, $hashed_password)) {
                $_SESSION['user_id'] = $user_id;
                $_SESSION['user_name'] = $username;
                $_SESSION['user_type'] = $user_type;

                if ($user_type === 'admin') {
                    header('Location: ../adminpanel/dashboard.php');
                } else {
                    header('Location: ../front_end/index.php');
                }
                exit;
            } else {
                $error_message = "Incorrect password.";
            }
        } else {
            $error_message = "No account found with that email.";
        }

        $stmt->close();
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign In - Wellness Journey</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', sans-serif;
            background: linear-gradient(to right, #c9d6ff, #e2e2e2);
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .container {
            width: 100%;
            max-width: 420px;
            background: #fff;
            padding: 40px;
            border-radius: 20px;
            box-shadow: 0 12px 25px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease;
        }

        .container:hover {
            transform: translateY(-3px);
        }

        .form-container h3 {
            text-align: center;
            margin-bottom: 25px;
            font-size: 26px;
            color: #333;
        }

        .form-container input {
            width: 100%;
            padding: 14px;
            margin: 12px 0;
            font-size: 15px;
            border: 1px solid #ccc;
            border-radius: 12px;
            transition: border-color 0.3s, box-shadow 0.3s;
        }

        .form-container input:focus {
            border-color: #6a82fb;
            box-shadow: 0 0 5px rgba(106, 130, 251, 0.5);
            outline: none;
        }

        .form-container button {
            width: 100%;
            padding: 14px;
            background: linear-gradient(to right, #667eea, #764ba2);
            border: none;
            border-radius: 12px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            margin-top: 10px;
            transition: background 0.3s ease;
        }

        .form-container button:hover {
            background: linear-gradient(to right, #5a67d8, #6b46c1);
        }

        .form-container p {
            text-align: center;
            margin-top: 18px;
            font-size: 14px;
            color: #555;
        }

        .form-container a {
            color: #6a82fb;
            font-weight: bold;
            text-decoration: none;
        }

        .form-container a:hover {
            text-decoration: underline;
        }

        .error-message {
            color: #e74c3c;
            background: #fdecea;
            border: 1px solid #f5c6cb;
            padding: 10px;
            border-radius: 10px;
            font-size: 14px;
            margin-bottom: 15px;
            text-align: center;
        }

        .forgot-password {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }

        .forgot-password a {
            color: #6a82fb;
            text-decoration: none;
        }

        .forgot-password a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h3>Sign In</h3>
            <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="email" name="email" placeholder="Email Address" required>
                <input type="password" name="password" placeholder="Password" required>

                <?php if ($error_message): ?>
                    <div class="error-message"><?php echo $error_message; ?></div>
                <?php endif; ?>

                <button type="submit" name="signin">Sign In</button>
            </form>
            <p>Don't have an account? <a href="signup.php">Sign Up</a></p>
            <div class="forgot-password">
                <p><a href="forgot_password.php">Forgot Password?</a></p>
            </div>
        </div>
    </div>
</body>
</html>

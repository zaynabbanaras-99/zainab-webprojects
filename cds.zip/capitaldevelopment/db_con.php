<?php
$conn = mysqli_connect('localhost', 'root', '', 'capital_development');

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
?>

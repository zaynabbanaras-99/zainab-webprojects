<?php include('navbar.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Our Products</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { 
      background: #ffffffff; 
      color: #fff; 
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; 
      margin: 0; 
      line-height: 1.6;
    }
    .container { max-width: 1200px; margin: auto; padding: 40px 20px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 30px; }
    .card { background: #1d2c47; border-radius: 12px; overflow: hidden; box-shadow: 0 8px 20px rgba(0,0,0,0.2); transition: transform 0.3s ease, box-shadow 0.3s ease; }
    .card:hover { transform: translateY(-5px); box-shadow: 0 12px 24px rgba(0,0,0,0.3); }
    .card img { width: 100%; height: 200px; object-fit: cover; background-color: #2c3e50; }
    .card-body { padding: 20px 25px 25px; }
    .section-title { text-align: center; margin-bottom: 40px; color: #000000ff; position: relative; font-size: 2.2rem; }
    .section-title::after { content: ''; display: block; width: 80px; height: 3px; background: #3e3f3eff; margin: 15px auto 0; }
    .card h2 { margin: 0 0 12px 0; color: #fff; font-size: 1.3rem; font-weight: 600; }
    .card p { font-size: 0.95rem; color: #cad1e0; margin-bottom: 20px; }
    .btn-link { display: inline-block; background: #13548aff; color: #fff; padding: 12px 25px; font-size: 16px; border: none; border-radius: 8px; cursor: pointer; transition: all 0.3s ease; text-decoration: none; font-weight: 500; margin-top: 10px; }
    .btn-link:hover { background: #000000ff; color: #fff; transform: translateY(-2px); box-shadow: 0 4px 12px rgba(76, 175, 80, 0.3); }
    .product-category { margin-bottom: 60px; }
  </style>
</head>
<body>

  <!-- Main Content -->
  <main>
    <!-- Termite Products -->
    <section class="product-category">
      <div class="container">
        <h1 class="section-title">Termite Control Products</h1>
        <div class="grid">
          <div class="card">
           <img src="../images/termite/termicol.png" alt="Termicol">

            <div class="card-body">
              <h2>Termicol</h2>
              <p>Advanced termite control solution for long-lasting protection against all termite species. Provides up to 5 years of prevention.</p>
            </div>
          </div>
          
          <div class="card">
            <img src="agenda_ec25.jpg" alt="Agenda EC25">
            <div class="card-body">
              <h2>Agenda EC25</h2>
              <p>Professional-grade termiticide that creates an impenetrable barrier against subterranean termites and other wood-destroying insects.</p>
            </div>
          </div>
          
          <div class="card">
            <img src="images/termite/termicure.jpg" alt="Termicure">
            <div class="card-body">
              <h2>Termicure</h2>
              <p>Complete termite elimination system that targets entire colonies including hidden breeding chambers and underground networks.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- Rodent Products -->
    <section class="product-category">
      <div class="container">
        <h1 class="section-title">Rodent Control Products</h1>
        <div class="grid">
          <div class="card">
            <img src="images/rodent/ratkiller.jpg" alt="Rat Killer">
            <div class="card-body">
              <h2>Rat Killer</h2>
              <p>Fast-acting rodenticide that eliminates rats and mice quickly while preventing secondary poisoning risks to non-target animals.</p>
            </div>
          </div>
          
          <div class="card">
            <img src="images/rodent/rodent_trap.jpg" alt="Rodent Trap">
            <div class="card-body">
              <h2>Rodent Trap</h2>
              <p>Humane and effective rodent capture system that allows for multiple catches without resetting. Ideal for commercial and residential use.</p>
            </div>
          </div>
        </div>
      </div>
    </section>

    <!-- General Fumigation Products -->
    <section class="product-category">
      <div class="container">
        <h1 class="section-title">General Fumigation Products</h1>
        <div class="grid">
          <div class="card">
            <img src="images/general fumigation/fumigation_machine.jpg" alt="Fumigation Machine">
            <div class="card-body">
              <h2>Fumigation Machine</h2>
              <p>Industrial-strength thermal fogger for large scale fumigation treatments. Covers up to 10,000 sq ft per treatment cycle.</p>
            </div>
          </div>
          
          <div class="card">
            <img src="images/general fumigation/chemical_spray.jpg" alt="Chemical Spray">
            <div class="card-body">
              <h2>Chemical Spray</h2>
              <p>EPA-approved fumigants for comprehensive pest elimination. Effective against 150+ insect species while being safe for indoor use when applied properly.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
    

    <div class="container" style="text-align:center; margin-top: 40px; margin-bottom: 60px;">
      <a href="services.php" class="btn-link">View Our Complete Services</a>
    </div>
  </main>

<?php include('footer.php'); ?>
</body>
</html>

<?php
session_start();
include("../db_con.php");

// Ensure user is logged in
if (!isset($_SESSION['user_id'])) {
    header("Location: signin.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$success_message = "";
$error_message = "";

// Fetch current user details
$stmt = $conn->prepare("SELECT username, email, user_type FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$stmt->bind_result($username, $email, $user_type);
$stmt->fetch();
$stmt->close();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $new_username = trim($_POST['username']);
    $new_email = trim($_POST['email']);
    $new_password = trim($_POST['password']);
    
    // Validate input
    if (empty($new_username) || empty($new_email)) {
        $error_message = "Username and Email cannot be empty.";
    } else {
        // Check if email already exists (excluding the current user)
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ? AND id != ?");
        $stmt->bind_param("si", $new_email, $user_id);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows > 0) {
            $error_message = "Email already in use.";
        } else {
            // If password is provided, hash it; otherwise, keep the old one
            if (!empty($new_password)) {
                if (strlen($new_password) < 6) {
                    $error_message = "Password must be at least 6 characters long.";
                } else {
                    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);
                    $update_query = "UPDATE users SET username = ?, email = ?, password = ? WHERE id = ?";
                    $stmt = $conn->prepare($update_query);
                    $stmt->bind_param("sssi", $new_username, $new_email, $hashed_password, $user_id);
                }
            } else {
                $update_query = "UPDATE users SET username = ?, email = ? WHERE id = ?";
                $stmt = $conn->prepare($update_query);
                $stmt->bind_param("ssi", $new_username, $new_email, $user_id);
            }

            if ($stmt->execute()) {
                // Update session variables to reflect changes immediately
                $_SESSION['user_name'] = $new_username;
                $_SESSION['user_email'] = $new_email;

                // Redirect to index.php after successful update
                header("Location: index.php?update=success");
                exit();
            } else {
                $error_message = "Error updating profile. Please try again.";
            }
        }
        $stmt->close();
    }
}
$conn->close();
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Profile</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color:#dceeff ;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 50%;
            margin: 50px auto;
            background: white;
            padding: 20px;
            box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .form-group {
            margin-bottom: 15px;
        }
        label {
            display: block;
            font-weight: bold;
        }
        input[type="text"], input[type="email"], input[type="password"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
        }
        button {
            width: 100%;
            padding: 10px;
            background:  #6a82fb;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
        }
        button:hover {
            background: linear-gradient(to right, #5a67d8, #6b46c1);
        }
        .message {
            text-align: center;
            padding: 10px;
            margin-top: 10px;
            font-weight: bold;
        }
        .success { color: green; }
        .error { color: red; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Edit Profile</h2>

        <!-- Success/Error Messages -->
        <?php if (!empty($success_message)) echo "<p class='message success'>$success_message</p>"; ?>
        <?php if (!empty($error_message)) echo "<p class='message error'>$error_message</p>"; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label>Full Name</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>" required>
            </div>

            <div class="form-group">
                <label>Email Address</label>
                <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            </div>

            <div class="form-group">
                <label>New Password (Leave blank to keep current password)</label>
                <input type="password" name="password">
            </div>

            <div class="form-group">
                <label>User Type</label>
                <input type="text" value="<?php echo ucfirst($user_type); ?>" disabled>
            </div>

            <button type="submit">Update Profile</button>
        </form>
    </div>
</body>
</html>

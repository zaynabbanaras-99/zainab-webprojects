<?php
session_start();
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';
require 'PHPMailer-master/src/Exception.php';
require '../db_con.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$message = "";

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    // Step 1: Send OTP
    if (isset($_POST['send_otp'])) {
        $email = trim($_POST['email']);
        $_SESSION['reset_email'] = $email;

        // Check if email exists
        $check = $conn->prepare("SELECT * FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $result = $check->get_result();

        if ($result->num_rows > 0) {
            $otp = rand(100000, 999999);
            $_SESSION['reset_otp'] = $otp;
            $_SESSION['otp_expiry'] = time() + (3 * 60); // 3 minutes expiry

            // Send OTP Email
            $mail = new PHPMailer(true);
            try {
                $mail->isSMTP();
                $mail->Host = 'smtp.gmail.com';
                $mail->SMTPAuth = true;
                $mail->Username = 'ilhamzahra005@gmail.com'; // your email
                $mail->Password = 'jzsfbwxjhghtlema'; // app password
                $mail->SMTPSecure = 'tls';
                $mail->Port = 587;

                $mail->setFrom('ilhamzahra005@gmail.com', 'Wellness Journey');
                $mail->addAddress($email);
                $mail->isHTML(true);
                $mail->Subject = 'Password Reset OTP';
                $mail->Body    = "Your OTP for password reset is: <b>$otp</b> (valid for 3 minutes)";

                $mail->send();
                $message = "OTP sent to your email.";
                $_SESSION['step'] = 'verify_otp';
            } catch (Exception $e) {
                $message = "Error sending OTP: {$mail->ErrorInfo}";
            }
        } else {
            $message = "Email not found.";
        }
    }

    // Step 2: Verify OTP
    elseif (isset($_POST['verify_otp'])) {
        $otp_entered = trim($_POST['otp']);
        if (isset($_SESSION['reset_otp']) && isset($_SESSION['otp_expiry'])) {
            if (time() > $_SESSION['otp_expiry']) {
                $message = "OTP expired. Please try again.";
                unset($_SESSION['reset_otp'], $_SESSION['otp_expiry']);
                $_SESSION['step'] = 'send_otp';
            } elseif ($otp_entered == $_SESSION['reset_otp']) {
                $_SESSION['step'] = 'reset_password';
                $message = "OTP verified. Please set your new password.";
            } else {
                $message = "Invalid OTP. Try again.";
            }
        } else {
            $message = "No OTP found. Please request again.";
        }
    }

    // Step 3: Reset Password
    elseif (isset($_POST['reset_password'])) {
        $new_password = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
        $email = $_SESSION['reset_email'];

        $update = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
        $update->bind_param("ss", $new_password, $email);
        if ($update->execute()) {
            $message = "Password reset successfully.";
            unset($_SESSION['reset_email'], $_SESSION['reset_otp'], $_SESSION['otp_expiry'], $_SESSION['step']);
        } else {
            $message = "Error updating password.";
        }
    }
}

if (!isset($_SESSION['step'])) {
    $_SESSION['step'] = 'send_otp';
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Forgot Password</title>
    <style>
        body { font-family: Arial; background: #f4f4f4; display: flex; justify-content: center; align-items: center; height: 100vh; }
        .container { background: white; padding: 20px; border-radius: 8px; width: 350px; box-shadow: 0px 0px 10px rgba(0,0,0,0.1); }
        input { width: 100%; padding: 10px; margin: 8px 0; }
        button { background: #4CAF50; color: white; padding: 10px; border: none; width: 100%; cursor: pointer; }
        button:hover { background: #45a049; }
        .message { color: red; margin-bottom: 10px; }
    </style>
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        <div class="message"><?php echo $message; ?></div>

        <?php if ($_SESSION['step'] == 'send_otp') { ?>
            <form method="POST">
                <input type="email" name="email" placeholder="Enter your email" required>
                <button type="submit" name="send_otp">Send OTP</button>
            </form>
        <?php } elseif ($_SESSION['step'] == 'verify_otp') { ?>
            <form method="POST">
                <input type="text" name="otp" placeholder="Enter OTP" required>
                <button type="submit" name="verify_otp">Verify OTP</button>
            </form>
        <?php } elseif ($_SESSION['step'] == 'reset_password') { ?>
            <form method="POST">
                <input type="password" name="new_password" placeholder="Enter new password" required>
                <button type="submit" name="reset_password">Reset Password</button>
            </form>
        <?php } ?>
    </div>
</body>
</html>
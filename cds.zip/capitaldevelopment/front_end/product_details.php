<?php
session_start();
include('../connects.php');

// Fetch the product ID from the query string and ensure it's an integer
$product_id = isset($_GET['product_id']) ? intval($_GET['product_id']) : 0;

// Check if the product ID is valid
if ($product_id <= 0) {
    die("Invalid product ID.");
}

// Fetch product details
$sql_product = "SELECT name, price, description, category_id FROM product WHERE product_id = $product_id";
$result_product = $conn->query($sql_product);
if (!$result_product) {
    die("Database query failed: " . $conn->error);
}

$product = $result_product->fetch_assoc();
if (!$product) {
    die("Product not found.");
}

// Fetch product image
$sql_image = "SELECT pro_img_name FROM product_images WHERE product_id = $product_id LIMIT 1";
$result_image = $conn->query($sql_image);
if (!$result_image) {
    die("Database query failed: " . $conn->error);
}

$image = $result_image->fetch_assoc();
$image_path = '../images/' . htmlspecialchars($image['pro_img_name']);
$product_name = htmlspecialchars($product['name']);
$product_price = htmlspecialchars($product['price']);
$product_description = htmlspecialchars($product['description']);
$category_id = htmlspecialchars($product['category_id']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $product_name; ?> - Product Details</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        /* Ensure content is below the navigation bar */
        .main-content {
            margin-top: 80px; /* Adjust this value based on your navigation bar's height */
            display: flex;
            justify-content: center;
            align-items: center;
            height: calc(100vh - 80px); /* Adjust height to prevent overflow issues */
        }
        .product-container {
            display: flex;
            background-color: #fff;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 100%;
            margin: auto;
        }
        .product-image {
            flex: 1;
            padding: 20px;
        }
        .product-image img {
            width: 100%;
            max-width: 300px;
            border-radius: 8px;
        }
        .product-details {
            flex: 2;
            padding: 20px;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .product-title {
            font-size: 24px;
            color: #960037;
            margin: 10px 0;
        }
        .product-price {
            font-size: 20px;
            color: #555;
            margin: 10px 0;
        }
        .product-description {
            font-size: 16px;
            color: #666;
            margin: 20px 0;
        }
        .button-group a {
            display: inline-block;
            margin: 5px;
            padding: 10px 20px;
            color: #fff;
            text-decoration: none;
            background-color: #960037;
            border-radius: 5px;
            font-size: 16px;
        }
        .button-group a:hover {
            background-color: #b33f5d;
        }
    </style>
</head>
<body>
<?php include('navigation_bar.php'); ?>

<div class="main-content">
    <div class="product-container">
        <div class="product-image">
            <img src="<?php echo $image_path; ?>" alt="<?php echo $product_name; ?>">
        </div>
        <div class="product-details">
            <h1 class="product-title"><?php echo $product_name; ?></h1>
            <p class="product-price">Rs <?php echo $product_price; ?></p>
            <p class="product-description"><?php echo $product_description; ?></p>
            <div class="button-group">
                <a href="customize.php?product_id=<?php echo urlencode($product_id); ?>&category_id=<?php echo urlencode($category_id); ?>&image=<?php echo urlencode($image['pro_img_name']); ?>">Customize</a>
            </div>
        </div>
    </div>
</div>

<?php include('footer.php'); ?>
</body>
</html>

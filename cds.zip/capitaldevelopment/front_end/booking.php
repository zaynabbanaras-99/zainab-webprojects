<?php
include('navbar.php');

// Handle form submission
$success = "";
$error = "";

$conn = new mysqli("localhost", "root", "", "capital_development");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name    = trim($_POST['customer_name']);
    $email   = trim($_POST['email']);
    $phone   = trim($_POST['phone']);
 $address = isset($_POST['address']) ? trim($_POST['address']) : '';

    $service = $_POST['service_type'];
    $date    = $_POST['preferred_date'];
    $message = trim($_POST['message']);

    $stmt = $conn->prepare("INSERT INTO bookings (customer_name, email, phone, address, service_type, preferred_date, message) VALUES (?, ?, ?, ?, ?, ?, ?)");

    if ($stmt) {
        $stmt->bind_param("sssssss", $name, $email, $phone, $address, $service, $date, $message);
        if ($stmt->execute()) {
            $success = "Your booking has been submitted successfully!";
        } else {
            $error = "Failed to submit booking. Please try again.";
        }
        $stmt->close();
    } else {
        $error = "Error preparing the statement.";
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Book a Service - Capital Development</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f6fa;
      margin: 0;
    }

    .container {
      max-width: 700px;
      margin: 60px auto;
      background: white;
      padding: 30px 40px;
      border-radius: 8px;
      box-shadow: 0 10px 25px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #000000ff;
      margin-bottom: 25px;
    }

    label {
      font-weight: 600;
      display: block;
      margin-top: 15px;
      color: #333;
    }

    input, select, textarea {
      width: 100%;
      padding: 10px;
      margin-top: 6px;
      border: 1px solid #ccc;
      border-radius: 6px;
      font-size: 14px;
    }

    textarea {
      resize: vertical;
    }

    button {
      margin-top: 20px;
      background-color: #0a4c74;
      color: #fff;
      border: none;
      padding: 12px 20px;
      border-radius: 6px;
      cursor: pointer;
      font-size: 15px;
    }

    .success {
      color: green;
      margin-top: 15px;
      text-align: center;
    }

    .error {
      color: red;
      margin-top: 15px;
      text-align: center;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Book a Service</h2>

  <?php if ($success): ?>
    <p class="success"><?= $success ?></p>
  <?php elseif ($error): ?>
    <p class="error"><?= $error ?></p>
  <?php endif; ?>

  <form method="POST" action="">
    <label for="customer_name">Full Name</label>
    <input type="text" name="customer_name" id="customer_name" required>

    <label for="email">Email Address</label>
    <input type="email" name="email" id="email" required>

    <label for="phone">Phone Number</label>
    <input type="text" name="phone" id="phone" required>

    <label for="address">Full Address</label>
    <input type="text" name="address" id="address" required>

    <label for="service_type">Select Service</label>
    <select name="service_type" id="service_type" required>
      <option value="">-- Select --</option>
      <option>Small Insect Control</option>
      <option>Pre and Post Anti-Termite Treatment</option>
      <option>Pest Bird Control</option>
      <option>Rat Control</option>
      <option>Water Tank Cleaning & Treatment</option>
      <option>Warehouse Hygienization</option>
      <option>Integrated Pest Management (IPM)</option>
      <option>Pest Management Training</option>
    </select>

    <label for="preferred_date">Preferred Date</label>
    <input type="date" name="preferred_date" id="preferred_date">

    <label for="message">Message / Notes</label>
    <textarea name="message" id="message" rows="4"></textarea>

    <button type="submit">Submit Booking</button>
  </form>
</div>

<?php include('footer.php'); ?>
</body>
</html>

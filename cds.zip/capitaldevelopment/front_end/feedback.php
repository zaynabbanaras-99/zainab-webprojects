<?php

include('../db_con.php');

$success = "";
$error = "";

// If user is logged in, optionally pre-fill username/email
$prefill_username = isset($_SESSION['username']) ? $_SESSION['username'] : "";
$prefill_email    = isset($_SESSION['email'])    ? $_SESSION['email'] : "";

// Only process when form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Use null coalescing to avoid undefined index notices
    $username = isset($_POST['username']) ? trim($_POST['username']) : '';
    $email    = isset($_POST['email'])    ? trim($_POST['email'])    : '';
    $comment  = isset($_POST['comment'])  ? trim($_POST['comment'])  : '';

    // Basic validation
    if ($username === '' || $email === '' || $comment === '') {
        $error = "⚠️ All fields are required.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "⚠️ Please enter a valid email address.";
    } else {
        // Prepared statement to avoid SQL injection
        $stmt = $conn->prepare("INSERT INTO user_feedback (username, email, comment) VALUES (?, ?, ?)");
        if ($stmt) {
            $stmt->bind_param("sss", $username, $email, $comment);
            if ($stmt->execute()) {
                $success = "✅ Thank you — your feedback has been submitted!";
                // Optionally clear the variables so form is empty after success
                $username = $email = $comment = "";
            } else {
                $error = "⚠️ Error submitting feedback: " . $stmt->error;
            }
            $stmt->close();
        } else {
            $error = "⚠️ Database error: " . $conn->error;
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>User Feedback - Capital Development Services</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { background: #f4f8f9; font-family: 'Poppins', sans-serif; }
    .feedback-container { width: 90%; max-width: 650px; background: #fff; margin: 80px auto; padding: 30px; border-radius: 12px; box-shadow: 0 0 12px rgba(0,0,0,0.08); }
    h2 { text-align: center; color: #333; margin-bottom: 20px; }
    input, textarea { width: 100%; padding: 12px; margin: 10px 0; border: 1px solid #ccc; border-radius: 8px; font-size: 16px; }
    button { width: 100%; background: #007bff; color: white; border: none; padding: 12px; font-size: 16px; border-radius: 8px; cursor: pointer; }
    button:hover { background: #0056b3; }
    .msg, .error { text-align: center; font-weight: bold; margin-bottom: 15px; padding: 10px; border-radius: 8px; }
    .msg { background: #d4edda; color: #155724; }
    .error { background: #f8d7da; color: #721c24; }
    .feedback-list { margin-top: 40px; }
    .feedback-item { background: #f9f9f9; border-left: 5px solid #007bff; padding: 15px; margin-bottom: 15px; border-radius: 8px; }
    .feedback-item small { color: gray; display: block; margin-top: 5px; }
  </style>
</head>
<body>

  <?php include('navbar.php'); ?>

  <div class="feedback-container">
    <h2>Share Your Feedback</h2>

    <?php if ($success): ?>
      <div class="msg"><?= htmlspecialchars($success) ?></div>
    <?php elseif ($error): ?>
      <div class="error"><?= htmlspecialchars($error) ?></div>
    <?php endif; ?>

    <form method="POST" action="">
      <!-- Pre-fill with session values if available, or keep submitted values on validation error -->
      <input type="text" name="username" placeholder="Your Name" required
             value="<?= isset($username) && $username !== '' ? htmlspecialchars($username) : htmlspecialchars($prefill_username) ?>">

      <input type="email" name="email" placeholder="Your Email" required
             value="<?= isset($email) && $email !== '' ? htmlspecialchars($email) : htmlspecialchars($prefill_email) ?>">

      <textarea name="comment" rows="5" placeholder="Write your feedback here..." required><?= isset($comment) ? htmlspecialchars($comment) : '' ?></textarea>

      <button type="submit">Submit Feedback</button>
    </form>

 
  </div>

  <?php include('footer.php'); ?>

</body>
</html>

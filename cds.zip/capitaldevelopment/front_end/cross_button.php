<?php
// Use the redirect path defined in the profile page
$redirectTo = isset($redirectTo) ? $redirectTo : 'dashboard.php';
?>

<button class="close-btn" onclick="window.location.href='<?php echo htmlspecialchars($redirectTo, ENT_QUOTES, 'UTF-8'); ?>'" aria-label="Close">
    <i class="fas fa-times"></i>
</button>

<style>
    .close-btn {
        position: absolute;
        top: 15px;
        right: 15px;
        background: #ff4d4d;
        color: white;
        border: none;
        padding: 10px;
        width: 40px;
        height: 40px;
        display: flex;
        align-items: center;
        justify-content: center;
        border-radius: 50%;
        font-size: 1.2rem;
        cursor: pointer;
        transition: background 0.3s ease, transform 0.2s ease;
    }
    .close-btn:hover {
        background: #cc0000;
        transform: scale(1.1);
    }
    .close-btn i {
        pointer-events: none;
    }
</style>

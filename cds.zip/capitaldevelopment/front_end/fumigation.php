<?php
include 'db_con.php';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Fumigation Services - Capital Development Services</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
        }
        h1 {
            font-weight: bold;
            color: #333;
        }
        /* Highlight Section */
        .highlight-section {
            background-color: #fff8e5;
            border-left: 5px solid #070981ff;
            padding: 20px;
            margin-bottom: 30px;
            font-size: 1rem;
            line-height: 1.6;
            border-radius: 5px;
        }
        /* Category Title */
        .category-title {
            background-color: #717aaaff;
            color: #000;
            padding: 12px 15px;
            border-radius: 8px;
            font-size: 1.3rem;
            font-weight: bold;
            margin-top: 30px;
        }
        /* Service Items */
        .list-group-item {
            background: #fff;
            border: 1px solid #ddd;
            margin-bottom: 5px;
            padding: 15px;
            border-radius: 5px;
        }
        .list-group-item strong {
            color: #444;
            font-size: 1.1rem;
        }
        /* Footer */
        footer {
            background-color: #222;
            color: white;
            padding: 15px 0;
            margin-top: 40px;
        }
        footer p {
            margin: 0;
        }
    </style>
</head>
<body>

<?php include 'navbar.php'; ?>

<div class="container my-5">
    <h1 class="text-center mb-4">Our Fumigation Services</h1>

    <!-- Influencing Paragraph -->
    <div class="highlight-section shadow-sm">
        <p><strong>At Capital Development Services</strong>, we understand that pests aren’t just a nuisance – they’re a threat to your health, property, and peace of mind. Our professional fumigation services are designed to deliver lasting protection, using eco-friendly, WHO-approved chemicals and advanced equipment to ensure complete eradication of harmful insects, termites, rodents, and other pests. Whether it’s your home, office, factory, or warehouse, our highly trained experts apply proven techniques that are safe, effective, and tailored to your specific needs. With over two decades of experience in Integrated Pest Management, we don’t just treat infestations – we prevent them, safeguarding your environment and giving you the confidence of a pest-free future.</p>
    </div>

    <?php
    $sql = "SELECT * FROM fumigation_services ORDER BY category, service_name";
    $result = $conn->query($sql);
    $current_category = '';

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            if ($current_category != $row['category']) {
                if ($current_category != '') echo "</ul>";
                $current_category = $row['category'];
                echo "<div class='category-title'>" . htmlspecialchars($current_category) . "</div><ul class='list-group mb-3'>";
            }
            echo "<li class='list-group-item'><strong>" . htmlspecialchars($row['service_name']) . "</strong><br>" . htmlspecialchars($row['description']) . "</li>";
        }
        echo "</ul>";
    } else {
        echo "<p class='text-center'>No fumigation services found.</p>";
    }
    ?>
</div>

<!-- FOOTER -->
<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> Capital Development Services. All Rights Reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

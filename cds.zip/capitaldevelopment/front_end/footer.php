       <!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Footer</title>
    <style>
        /* Footer Styles */
        footer {
            background-color: #343a40;
            color: white;
            text-align: center;
            padding: 20px 0;
            font-size: 1.0em;
        }
        </style>
        </head>
        <body>
        <footer>
        <p>&copy; 2025 Capital Development Services. All rights reserved</p>
    </footer>
    </body>
    </html>
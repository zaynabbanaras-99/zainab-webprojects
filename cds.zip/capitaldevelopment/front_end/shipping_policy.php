<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shipping Policy - Capital Development Services</title>
    <style>
        body {
            background-color: #f5f5dc; /* beige background */
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            max-width: 1200px;
        }

        .header {
            background-color: #fff; /* light beige background */
            color: #960037;
            padding: 20px 0;
            text-align: center;
            padding-top: 130px;
        }

        .shipping-container {
            display: grid;
            grid-template-columns: repeat(2, 1fr);
            gap: 20px;
            margin-top: 20px;
        }

        .shipping-method {
            background-color: #fff;
            border: 1px solid #ddd;
            border-radius: 5px;
            text-align: center;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            max-width: 300px;
            margin: 0 auto;
            opacity: 0;
            transform: translateY(20px);
            animation: fadeInUp 1s forwards;
        }

        .shipping-method img {
            width: 70%;
            height: auto;
            margin-bottom: 10px;
            border-radius: 5px;
        }

        .shipping-method h2 {
            font-size: 20px;
            color: #960037;
            margin-bottom: 10px;
        }

        .shipping-method p {
            font-size: 14px;
            color: #555;
        }

        .shipping-method.centered {
            grid-column: 1 / -1;
            justify-self: center;
        }

        @keyframes fadeInUp {
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        .shipping-method:nth-child(2) {
            animation-delay: 0.3s;
        }

        .shipping-method:nth-child(3) {
            animation-delay: 0.6s;
        }

        footer {
            background-color: #960037;
            color: white;
            text-align: center;
            padding: 10px 0;
            margin-top: 40px;
        }

        .social-icons {
            list-style: none;
            padding: 0;
        }

        .social-icons li {
            display: inline;
            margin: 0 10px;
        }

        .social-icons a {
            color: white;
            text-decoration: none;
            font-size: 24px;
        }

        .social-icons a:hover {
            color: #c16a5b;
        }
    </style>
</head>

<body>
    <?php include('navigation_bar.php'); ?>

    <div class="header">
        <h1>Shipping Policy</h1>
    </div>

    <div class="shipping-container container">
        <div class="shipping-method">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSVsr8DDvIqJK8XqSrnDoWRZGEZXQPyFzME1jxJAQJQwt8Annk&s" alt="Standard Shipping">
            <h2>Standard Shipping</h2>
            <p>5-7 business days. Orders processed within 2 business days.</p>
        </div>

        <div class="shipping-method">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR5q-wHpHluD2pIKqqv1_q4zQ9K-3Dz0LrwOW2PLb9c4QOPl2xX&s" alt="Express Shipping">
            <h2>Express Shipping</h2>
            <p>2-3 business days. Orders processed within 1 business day.</p>
        </div>

        <div class="shipping-method centered">
            <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSqd0m-t6flk5z8jzzN1t7KqExehtuv5U0krzaoeU2ai9A3o4&s" alt="Overnight Shipping">
            <h2>Overnight Shipping</h2>
            <p>Next business day. Immediate processing.</p>
        </div>
    </div>


    <?php include('footer.php'); ?>
</body>

</html>

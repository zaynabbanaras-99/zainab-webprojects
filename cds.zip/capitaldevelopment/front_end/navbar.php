<?php
session_start();
$isLoggedIn = isset($_SESSION['user_name']);
$userName = $isLoggedIn ? $_SESSION['user_name'] : 'Guest';
?>
<!-- NAVBAR.PHP -->
<style>
  /* Top Header */
  .top-header {
    background-color: #1d3a77;
    color: white;
    text-align: center;
    padding: 15px 0;
    font-size: 1.8rem;
    font-weight: bold;
  }

  /* Main Navigation */
  nav.custom-nav {
    background-color: #666;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 0.6rem 2rem;
  }

  .nav-left img {
    height: 45px;
  }

  /* Center links area */
  .nav-center {
    flex: 1;
    display: flex;
    justify-content: center;
    gap: 25px;
    align-items: center;
  }

  .nav-center a {
    color: white;
    text-decoration: none;
    font-weight: bold;
    font-size: 1rem;
    transition: color 0.3s ease;
  }

  .nav-center a:hover {
    color: #ffc107;
  }

  /* Optional Right Section */
  .nav-right {
    background-color: #f8f9fa;
    padding: 6px 12px;
    border-radius: 5px;
    font-weight: bold;
    display: flex;
    gap: 10px;
    align-items: center;
  }

  .nav-right a {
    color: #0d6efd;
    text-decoration: none;
  }

  .nav-right a:hover {
    text-decoration: underline;
  }

  .divider {
    color: #999;
  }
</style>

<!-- Top Header -->
<div class="top-header">
  Capital Development Services
</div>

<!-- Main Navigation Bar -->
<nav class="custom-nav">
  <!-- Left: Logo -->
  <div class="nav-left">
  <img src="images/logo.jpg" alt="Company Logo" style="height:60px;">

  </div>

  <!-- Center: Navigation Links -->
  <div class="nav-center">
    <a href="index.php">Home</a>
    <a href="Aboutus.php">About Us</a>
    <a href="services.php">Services</a>
    <a href="fumigation.php">Fumigation</a>
    <a href="products.php">Products</a>
    <a href="booking.php">Book a Service</a>
    <a href="contact.php">Contact Us</a>
    <a href="feedback.php">Feedback</a>
  </div>

</nav>

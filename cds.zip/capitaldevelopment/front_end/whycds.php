<?php include('navbar.php'); ?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Why CDS & Consultancy Services</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body { background: #0f1b2b; color: #fff; font-family: sans-serif; margin: 0; }
  .container { max-width: 1100px; margin: auto; padding: 40px; }
  h1, h2 { color: #000000ff; }
  ul { list-style: disc; padding-left: 20px; color: #ccc; }
  p { color: #ccc; line-height: 1.6; }

  .section {
    background: #fcfcfc63;
    padding: 20px;
    margin-bottom: 30px;
    border-radius: 10px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.3);
  }

  table {
    width: 100%;
    border-collapse: collapse;
    margin-top: 15px;
  }
  table th, table td {
    border: 1px solid #000000ff;
    padding: 10px;
    text-align: left;
  }
  table th {
    background: #000000ff;
    color: #fff;
  }
  table tr:nth-child(even) {
    background: #96a5c4ff;
  }
</style>
</head>
<body>

<div class="container">

  <div class="section">
    <h1>Why CDS?</h1>
    <ul>
      <li>Qualified and well experienced Entomologist</li>
      <li>Well trained staff</li>
      <li>Standard procedures supported by documents</li>
      <li>Using mainly W.H.O approved chemicals</li>
      <li>Efficient after sales service</li>
      <li>Wide range of services to cater your specific needs</li>
    </ul>
  </div>

  <div class="section">
    <h1>Consultancy Services</h1>
    <p>
      <strong>Quality Management Systems</strong><br>
      CDS offers a suite of professional services designed to help organizations implement quality management systems that conform to and are certified to documented standards.
      Our services can be tailored to meet the specific needs of your business. 
      We also offer you the advantage of a single point of contact for your third-party registration needs.
    </p>

    <h2>Standards We Support</h2>
    <table>
      <tr>
        <th>Standard</th>
        <th>Description</th>
      </tr>
      <tr>
        <td>ISO 9001</td>
        <td>QUALITY MANAGEMENT SYSTEM</td>
      </tr>
      <tr>
        <td>ISO 22000</td>
        <td>FOOD SAFETY MANAGEMENT SYSTEM</td>
      </tr>
      <tr>
        <td>KOSHER</td>
        <td>JEWISH FOOD SAFETY MANAGEMENT SYSTEM</td>
      </tr>
      <tr>
        <td>BRC ISSUE 6</td>
        <td>BRITISH RETAIL CONSORTIUM: GLOBAL FOOD SAFETY INITIATIVE</td>
      </tr>
      <tr>
        <td>THE SQF CODE</td>
        <td>SAFE QUALITY FOOD – LEVEL 3 IFS VERSION 6 INTERNATIONAL FOOD STANDARD</td>
      </tr>
      <tr>
        <td>OHSAS 18001</td>
        <td>OCCUPATIONAL HEALTH AND SAFETY MANAGEMENT SYSTEM</td>
      </tr>
      <tr>
        <td>HACCP (DUTCH)</td>
        <td>HAZARD ANALYSIS CRITICAL CONTROL POINTS</td>
      </tr>
      <tr>
        <td>ISO 14001</td>
        <td>ENVIRONMENTAL MANAGEMENT SYSTEM</td>
      </tr>
    </table>
  </div>

</div>

<?php include('footer.php'); ?>
</body>
</html>

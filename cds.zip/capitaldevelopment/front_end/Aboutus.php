<?php 
include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>About Us - Capital Development Services</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    body {
      font-family: Arial, sans-serif;
    }
    .section {
      padding: 60px 20px;
      background-color: #f4f4f4;
      text-align: center;
    }
    .section h2 {
      font-size: 2.5rem;
      font-weight: bold;
      color: #233D7C;
      margin-bottom: 20px;
    }
    .section p {
      font-size: 1.1rem;
      max-width: 800px;
      margin: 0 auto 30px;
      color: #333;
      line-height: 1.8;
    }
    .profile-img {
      max-width: 200px;
      border-radius: 10px;
      margin-bottom: 20px;
      box-shadow: 0 0 10px rgba(0,0,0,0.2);
    }
    .card-box {
      display: flex;
      justify-content: center;
      gap: 30px;
      flex-wrap: wrap;
      margin-top: 40px;
    }
    .info-card {
      background: white;
      border: 1px solid #ddd;
      border-radius: 10px;
      padding: 25px;
      width: 300px;
      box-shadow: 0 0 10px rgba(0,0,0,0.05);
      text-align: left;
    }
    .info-card h4 {
      color: #233D7C;
      font-weight: bold;
      margin-bottom: 15px;
    }
    .info-card p {
      font-size: 1rem;
      color: #444;
      line-height: 1.6;
    }
    .btn-yellow {
      background-color: #f4c542;
      border: none;
      color: #000;
      font-weight: 600;
      padding: 10px 20px;
      border-radius: 5px;
      text-decoration: none;
      display: inline-block;
      margin-top: 30px;
    }
    .btn-yellow:hover {
      background-color: #e4b62d;
    }

    /* Contact Call-to-Action */
.cta-box {
  background-color: #c9d9fdff;
  color: white;
  padding: 30px 20px;
  border-radius: 10px;
  max-width: 800px;
  margin: 50px auto 0;
  box-shadow: 0 0 15px rgba(0,0,0,0.15);
}
.cta-box h4 {
  font-size: 1.5rem;
  margin-bottom: 15px;
  font-weight: bold;
  color: black; /* Changed to black */
}
.cta-box p {
  font-size: 1.1rem;
  margin-bottom: 10px;
}
.cta-box a {
  color: #000000ff;
  text-decoration: underline;
  font-weight: bold;
}
on: underline;
      font-weight: bold;
    }
  </style>
</head>
<body>

<section class="section">
  <!-- Founder Image -->
  <img src="images/1806262e-f97b-4420-8118-15e4bda5f556.jpg" alt="Founder Image" class="profile-img" />

  <h2>About Capital Development Services</h2>
  <p>Our mission is to deliver professional pest control solutions with guaranteed satisfaction, safety, and sustainability for every home and business we serve. We not only target termites but also provide comprehensive control of general pests that can spread, contaminate, or affect surrounding areas, ensuring a healthier, safer, and more comfortable environment for all.</p>

  <div class="card-box">
    <div class="info-card">
      <h4>Our Mission</h4>
      <p>To deliver professional pest control solutions with guaranteed satisfaction, safety, and sustainability for every home and business we serve.</p>
    </div>
    <div class="info-card">
      <h4>Our Vision</h4>
      <p>To be recognized as Pakistan’s top-rated termite control provider through integrity, innovation, and exceptional service delivery.</p>
    </div>
    <div class="info-card">
      <h4>Our Team</h4>
      <p>Our team includes certified exterminators, inspection officers, and support staff dedicated to keeping your space termite-free.</p>
    </div>
  </div>

  <!-- Contact CTA -->
  <div class="cta-box">
    <h4>Contact Our Entomologist Today</h4>
    <p>📞 Call us now at <a href="tel:03215059001">0321-5059001</a></p>
    <p>📧 Email: <a href="mailto:akhlaqhussain837@gmail.com">akhlaqhussain837@gmail.com</a></p>
    <p>Let’s discuss your specific pest control needs and provide the right solution for you.</p>
  </div>

  <a href="services.php" class="btn-yellow">Explore Our Services</a>
</section>

<?php include 'footer.php'; ?>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

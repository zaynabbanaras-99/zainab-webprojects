<?php
include 'navbar.php';

// Database connection
$conn = new mysqli("localhost", "root", "", "capital_development");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch hygiene materials
$sql = "SELECT * FROM hygiene_material_supplier";
$result = $conn->query($sql);

// Check if query worked
if ($result === false) {
    echo "Database query failed: " . $conn->error;
} else {
    if ($result->num_rows > 0) {
        echo '<div class="container mt-5">';
        echo '<h2 class="text-center mb-4">Hygiene Material Supplier</h2>';
        echo '<div class="row">';
        
        while ($row = $result->fetch_assoc()) {
            echo '<div class="col-md-4 mb-4">';
            echo '<div class="card h-100">';
            echo '<div class="card-body">';
            echo '<p class="card-text">' . htmlspecialchars($row['description']) . '</p>';
            echo '</div>';
            echo '</div>';
            echo '</div>';
        }

        echo '</div>';
        echo '</div>';
    } else {
        echo "<p class='text-center mt-5'>No hygiene materials found.</p>";
    }
}

include 'footer.php';
$conn->close();
?>

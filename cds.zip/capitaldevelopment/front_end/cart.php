<?php

include('../db_con.php'); // Fixed path

if (isset($_GET['action']) && $_GET['action'] == 'add' && isset($_GET['id'])) {
    $product_id = $_GET['id'];

    // Fetch the product details from the database
    $sql = "SELECT * FROM product WHERE product_id = '$product_id'";
    $result = $conn->query($sql);
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $product_name = $row['name'];
        $product_price = $row['price'];

        // Fetch the product image
        $sql_image = "SELECT pro_img_name FROM product_images WHERE product_id = '$product_id' LIMIT 1";
        $result_image = $conn->query($sql_image);
        $image_name = $result_image->num_rows > 0 ? $result_image->fetch_assoc()['pro_img_name'] : 'default.png';

        // Add to cart functionality
        if (isset($_SESSION['cart'][$product_id])) {
            $_SESSION['cart'][$product_id]['quantity']++;
        } else {
            $_SESSION['cart'][$product_id] = array(
                'name' => $product_name,
                'price' => $product_price,
                'quantity' => 1,
                'image' => $image_name
            );
        }
    }

    echo "<script>window.location.href = 'add_cart.php';</script>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_product_id'])) {
    $delete_product_id = $_POST['delete_product_id'];
    unset($_SESSION['cart'][$delete_product_id]);
    echo "<script>window.location.href = 'add_cart.php';</script>";
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_all'])) {
    unset($_SESSION['cart']);
    echo "<script>window.location.href = 'add_cart.php';</script>";
}

$cart_is_empty = !isset($_SESSION['cart']) || empty($_SESSION['cart']);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart - Custom Chic</title>
    <style>
    
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
            display: flex;
            flex-direction: column;
            min-height: 100vh;
        }
        main {
            flex: 1;
            margin-top: 80px;
            padding: 20px;
            box-sizing: border-box;
            overflow: auto;
            padding-bottom: 100px;
        }
        .cart-container {
            max-width: 800px;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
            margin-bottom: 60px;
        }
        .cart-heading {
            text-align: center;
            color: #970037;
            margin-bottom: 20px;
        }
        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            border-bottom: 1px solid #ddd;
            padding-bottom: 10px;
        }
        .product-img {
            width: 100px;
            height: auto;
        }
        .product-details {
            flex-grow: 1;
            margin-left: 20px;
        }
        .product-name {
            font-size: 18px;
            color: #970037;
        }
        .product-price {
            color: #970037;
            font-size: 16px;
            margin-bottom: 10px;
        }
        .quantity-display {
            font-size: 16px;
            color: #333;
            margin-top: 10px;
        }
        .item-buttons {
            display: flex;
            align-items: center;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 10px;
        }
        .delete-btn {
            background-color: #970037;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
        }
        .total-container {
            position: absolute;
            bottom: 20px;
            background-color: #fff;
            padding: 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 250px;
            height: auto;
            z-index: 10;
            right: 20px;
        }
        .subtotal, .total {
            font-size: 18px;
            color: #333;
        }
        .checkout-btn {
            background-color: #970037;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            margin-top: 10px;
            width: 60%;
            margin: 20px auto;
        }
        .bottom-buttons {
            display: flex;
            justify-content: flex-start;
            gap: 10px;
            margin-top: 40px;
            margin-bottom: 10px;
            padding-bottom: 10px;
        }
        .continue-btn, .delete-all-btn {
            font-size: 18px;
            background-color: #970037;
            color: white;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 4px;
            width: 220px;
            max-width: 200px;
            min-height: 70px;
            margin-top: 20px;
        }
        .continue-btn:hover,
        .delete-all-btn:hover,
        .delete-btn:hover,
        .checkout-btn:hover {
            opacity: 0.9;
        }
    </style>
</head>
<body>

<?php include('navbar.php'); ?>  <!-- ✅ Correct path -->

<main>
    <div class="cart-container">
        <h1 class="cart-heading">Your Shopping Cart</h1>

        <?php if ($cart_is_empty) : ?>
            <p>Your cart is currently empty.</p>
        <?php else : ?>
            <?php
            $total = 0;
            foreach ($_SESSION['cart'] as $product_id => $details) {
                $subtotal = $details['price'] * $details['quantity'];
                $Size = @$details['size'];
                $Style = @$details['style'];
                $Color = @$details['color'];
                $Fabric = @$details['fabric'];
                $total += $subtotal;
            ?>
                <div class="cart-item">
                    <img src="../images/<?php echo htmlspecialchars($details['image']); ?>" alt="Product Image" class="product-img">
                    <div class="product-details">
                        <h2 class="product-name"><?php echo htmlspecialchars($details['name']); ?></h2>
                        <p class="product-price">Price: $<?php echo htmlspecialchars($details['price']); ?></p>
                        <p class="quantity-display">Quantity: <?php echo htmlspecialchars($details['quantity']); ?></p>
                        <?php
                        if (isset($details['size'])) echo "<p class='product-price'>Size: $Size</p>";
                        if (isset($details['style'])) echo "<p class='product-price'>Style: $Style</p>";
                        if (isset($details['color'])) echo "<p class='product-price'>Color: $Color</p>";
                        if (isset($details['fabric'])) echo "<p class='product-price'>Fabric: $Fabric</p>";
                        ?>
                    </div>
                    <div class="item-buttons">
                        <form method="post" action="">
                            <input type="hidden" name="delete_product_id" value="<?php echo $product_id; ?>">
                            <button type="submit" class="delete-btn">Delete</button>
                        </form>
                    </div>
                </div>
            <?php } ?>

            <div class="total-container">
                <h3 class="total">Total: $<?php echo number_format($total, 2); ?></h3>
                <h3 class="subtotal">Subtotal: $<?php echo number_format($total, 2); ?></h3>
                <form method="post" action="checkout.php">
                    <?php foreach ($_SESSION['cart'] as $product_id => $details): ?>
                        <input type="hidden" name="product_id[]" value="<?php echo $product_id; ?>">
                        <input type="hidden" name="quantity[]" value="<?php echo $details['quantity']; ?>">
                    <?php endforeach; ?>
                    <button type="submit" class="checkout-btn">Proceed to Checkout</button>
                </form>
            </div>
        <?php endif; ?>
    </div>

    <div class="bottom-buttons">
        <a href="products.php" class="continue-btn">Continue Shopping</a>
        <form method="post" action="">
            <input type="hidden" name="delete_all" value="1">
            <button type="submit" class="delete-all-btn">Delete All</button>
        </form>
    </div>
</main>

<?php include('footer.php'); ?>  
</body>
</html>

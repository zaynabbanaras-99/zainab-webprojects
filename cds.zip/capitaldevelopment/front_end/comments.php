<?php
// Start session to access session variables
session_start();
include('../connects.php');

// Check if the user is logged in
if (!isset($_SESSION['UID'])) {
    echo "You need to be logged in to leave a comment.";
    exit();
}

// Handle comment submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $comment = $_POST['comment'];
    $user_id = $_SESSION['UID']; // Get user ID from session

    // Prepare and bind
    $stmt = $conn->prepare("INSERT INTO user_feedback (user_id, comment, date_time) VALUES (?, ?, NOW())");
    $stmt->bind_param("is", $user_id, $comment);

    // Execute the statement
    if ($stmt->execute()) {
        // Redirect back to the same page to display the new comment
        header("Location: " . $_SERVER['PHP_SELF']);
        exit();
    } else {
        echo "Error: " . $stmt->error;
    }

    // Close the statement
    $stmt->close();
}

// Fetch usernames
$user_names = [];
$sql_users = "SELECT user_id, user_name FROM user";
$result_users = $conn->query($sql_users);
if ($result_users->num_rows > 0) {
    while ($row = $result_users->fetch_assoc()) {
        $user_names[$row['user_id']] = $row['user_name'];
    }
}

// Fetch comments from the database
$sql_comments = "SELECT user_id, comment, date_time FROM user_feedback ORDER BY date_time DESC";
$result_comments = $conn->query($sql_comments);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .comments-section {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 20px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        .comment {
            border: 1px solid #970037;
            border-radius: 5px;
            padding: 15px;
            margin-bottom: 15px;
            background: #fff2f6;
            transition: background-color 0.3s, transform 0.3s;
            max-width: 100%;
        }

        .comment:hover {
            background: #ffe6f0;
            transform: scale(1.01);
        }

        .leave-comment {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2);
            max-width: 800px;
            margin-left: auto;
            margin-right: auto;
        }

        textarea {
            width: 100%;
            height: 100px;
            margin-bottom: 10px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
            resize: none;
        }

        button {
            padding: 10px 15px;
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #6a002a;
        }

        .comment-header {
            font-weight: bold;
            color: #970037;
        }

        .comment-date {
            font-size: 0.9em;
            color: #888;
        }
    </style>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Comments Page</title>
</head>
<body>
<?php include('navigation_bar.php'); ?>
    <div class="comments-section">
        <h2 style="color: #970037;">User Comments</h2>
        <?php if ($result_comments->num_rows > 0): ?>
            <?php while($row = $result_comments->fetch_assoc()): ?>
                <div class="comment">
                    <p class="comment-header"><?php echo htmlspecialchars($user_names[$row['user_id']] ?? 'Unknown'); ?></p>
                    <p class="comment-date"><?php echo htmlspecialchars($row['date_time']); ?></p>
                    <p><?php echo htmlspecialchars($row['comment']); ?></p>
                </div>
            <?php endwhile; ?>
        <?php else: ?>
            <p>No comments yet.</p>
        <?php endif; ?>
    </div>

    <div class="leave-comment">
        <h2 style="color: #970037;">Leave a Comment</h2>
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <textarea name="comment" required placeholder="Write your comment here..."></textarea>
            <input type="hidden" name="user_id" value="<?php echo $_SESSION['UID']; ?>">
            <button type="submit">Submit</button>
        </form>
    </div>

    <?php
    // Close the database connection
    $conn->close();
    ?>
</body>
</html>

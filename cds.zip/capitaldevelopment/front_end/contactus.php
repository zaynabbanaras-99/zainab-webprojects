<?php include '../navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Capital Development Services</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f8f9fa;
        }

        .contact-section {
            max-width: 1100px;
            margin: 50px auto;
            padding: 30px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.1);
        }

        .contact-section h2 {
            text-align: center;
            font-size: 2rem;
            margin-bottom: 20px;
            color: #005f73;
        }

        .contact-info {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px;
            margin-bottom: 30px;
        }

        .contact-info div {
            background: #e6f2f2;
            padding: 20px;
            border-radius: 10px;
            text-align: center;
            transition: transform 0.2s ease-in-out;
        }

        .contact-info div:hover {
            transform: scale(1.05);
        }

        .contact-info h3 {
            color: #0a9396;
            margin-bottom: 10px;
        }

        .contact-info p {
            margin: 0;
            color: #333;
        }

        .contact-form {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .contact-form input, 
        .contact-form textarea {
            width: 100%;
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            outline: none;
            font-size: 1rem;
            transition: border 0.2s;
        }

        .contact-form input:focus, 
        .contact-form textarea:focus {
            border-color: #0a9396;
        }

        .contact-form button {
            background: #0a9396;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 8px;
            font-size: 1.1rem;
            cursor: pointer;
            transition: background 0.3s;
        }

        .contact-form button:hover {
            background: #007f7f;
        }

        @media (max-width: 600px) {
            .contact-section {
                padding: 20px;
            }
        }
    </style>
</head>
<body>

<section class="contact-section">
    <h2>Contact Us</h2>

    <div class="contact-info">
        <div>
            <h3>📍 Address</h3>
            <p>Capital Development Services, Lahore, Pakistan</p>
        </div>
        <div>
            <h3>📞 Phone</h3>
            <p>+92 300 1234567</p>
        </div>
        <div>
            <h3>✉ Email</h3>
            <p>info@cds.com</p>
        </div>
    </div>

    <form class="contact-form" method="POST" action="">
        <input type="text" name="name" placeholder="Your Name" required>
        <input type="email" name="email" placeholder="Your Email" required>
        <textarea name="message" rows="5" placeholder="Your Message..." required></textarea>
        <button type="submit">Send Message</button>
    </form>
</section>

<?php include '../footer.php'; ?>

</body>
</html>

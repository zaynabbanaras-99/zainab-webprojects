<?php
session_start();
include('../connects.php');

// Initialize total price and errors
$total_price = 0;
$errors = [];
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_email = $_POST['user_email'] ?? '';
    $full_name = $_POST['full_name'] ?? '';
    $phone_no = $_POST['phone_no'] ?? '';
    $shipping_address = $_POST['shipping_address'] ?? '';
    $shipping_method = $_POST['shipping_method'] ?? '';
    $payment_method_used = $_POST['payment_method_used'] ?? '';
    $order_type = $_POST['order_type'] ?? '';

    if (empty($user_email) || empty($full_name) || empty($phone_no) || empty($shipping_address)) {
        $errors[] = 'All fields are required.';
    }

    if (empty($errors)) {
        $sql = "INSERT INTO order_placed (user_email, full_name, phone_no, shipping_address, shipping_method, payment_method_used, order_type)
                VALUES ('$user_email', '$full_name', '$phone_no', '$shipping_address', '$shipping_method', '$payment_method_used', '$order_type')";
        
        if ($conn->query($sql) === TRUE) {
            $order_id = $conn->insert_id;

            if (!empty($_SESSION['cart'])) {
                foreach ($_SESSION['cart'] as $product_id => $item) {
                    $quantity = $item['quantity'] ?? 0;
                    $price = $item['price'] ?? 0;
                    $total_price += $price * $quantity;

                    // Insert product details along with variations into the database
                    $size = $item['size'] ?? '';
                    $style = $item['style'] ?? '';
                    $color = $item['color'] ?? '';
                    $fabric = $item['fabric'] ?? '';

                    $conn->query("INSERT INTO orders_line (order_id, product_id, quantity, price, size, style, color, fabric)
                                 VALUES ('$order_id', '$product_id', '$quantity', '$price', '$size', '$style', '$color', '$fabric')");
                }
            }

            // Clear cart and form fields
            $_SESSION['cart'] = [];
            $user_email = '';
            $full_name = '';
            $phone_no = '';
            $shipping_address = '';
            $shipping_method = '';
            $payment_method_used = '';
            $order_type = '';

            $success_message = 'Order placed successfully!';
        } else {
            $errors[] = 'Error: ' . $conn->error;
        }
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f7f7f7;
            margin: 0;
            padding: 0;
            padding-top: 70px;
        }
        .navbar {
            background-color: #970037;
            padding: 15px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            color: white;
        }
        .navbar a {
            color: white;
            text-decoration: none;
            padding: 10px;
        }
        .navbar a:hover {
            background-color: #c73a55;
            border-radius: 5px;
        }
        h1 {
            text-align: center;
            color: #970037;
            margin-top: 50px; /* Adjusted margin to avoid overlapping */
            font-size: 36px; /* Increased font size for better visibility */
        }
        .container {
            display: flex;
            justify-content: center;
            align-items: flex-start;
            padding: 40px;
            width: 100%;
        }
        form {
            width: 50%;
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
            margin-right: 20px;
        }
        form label {
            display: block;
            margin-bottom: 8px;
            font-weight: bold;
            color: #970037;
        }
        input, select, textarea {
            width: calc(100% - 16px);
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }
        .submit-btn {
            background-color: #970037;
            color: white;
            padding: 15px 30px;
            border: none;
            cursor: pointer;
            border-radius: 4px;
            width: auto;
            display: block;
            margin: 0 auto;
            font-size: 16px;
        }
        .error {
            color: red;
            margin-bottom: 15px;
        }
        .summary {
            width: 350px;
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0px 0px 10px rgba(0,0,0,0.1);
        }
        .summary h2 {
            margin-top: 0;
            color: #970037;
        }
        .success-message {
            display: <?= $success_message ? 'block' : 'none' ?>;
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            border-radius: 5px;
            margin-top: 20px;
            text-align: center;
        }
        

.navbar {
    position: fixed;
    top: 0;
    left: 0;
    width: 100%;
    background-color: #fff;
    box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
    z-index: 1000;
    padding: 10px 20px;
    box-sizing: border-box;
    padding-top: 70px; /* Adjust for fixed navbar height */
}

footer {
    background-color: #f1f1f1;
    padding: 10px 0;
    text-align: center;
    position: relative;
    width: 100%;
    bottom: 0;
    margin-top: 40px; /* Ensure the footer is below all content */
}
    </style>
</head>
<body>
<?php include('navigation_bar.php'); ?>

<h1>Checkout</h1>

<div class="container">
    <form method="POST" action="">
        <h2 class="checkout-header">Checkout Form</h2>
        
        <?php if (!empty($errors)) : ?>
            <ul>
                <?php foreach ($errors as $error) : ?>
                    <li><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
        
        <?php if (!empty($success_message)) : ?>
            <p><?php echo $success_message; ?></p>
        <?php endif; ?>

        <label for="user_email">Email:</label>
        <input type="text" id="user_email" name="user_email" value="<?= htmlspecialchars($user_email) ?>" required>

        <label for="full_name">Full Name:</label>
        <input type="text" id="full_name" name="full_name" value="<?= htmlspecialchars($full_name) ?>" required>

        <label for="phone_no">Phone Number:</label>
        <input type="text" id="phone_no" name="phone_no" value="<?= htmlspecialchars($phone_no) ?>" required>

        <label for="shipping_address">Shipping Address:</label>
        <textarea id="shipping_address" name="shipping_address" required><?= htmlspecialchars($shipping_address) ?></textarea>

        <label for="shipping_method">Shipping Method:</label>
        <select id="shipping_method" name="shipping_method" required>
            <option value="standard" <?= ($shipping_method == 'standard') ? 'selected' : '' ?>>Standard Shipping</option>
            <option value="express" <?= ($shipping_method == 'express') ? 'selected' : '' ?>>Express Shipping</option>
            <option value="overnight" <?= ($shipping_method == 'overnight') ? 'selected' : '' ?>>Overnight Shipping</option>
        </select>

        <label for="payment_method_used">Payment Method:</label>
        <select id="payment_method_used" name="payment_method_used" required>
            <option value="credit_card" <?= ($payment_method_used == 'credit_card') ? 'selected' : '' ?>>Credit Card</option>
            <option value="cash_on_delivery" <?= ($payment_method_used == 'cash_on_delivery') ? 'selected' : '' ?>>Cash on Delivery</option>
        </select>

        <label for="order_type">Order Type:</label>
        <select id="order_type" name="order_type" required>
            <option value="Direct purchase" <?= ($order_type == 'Direct purchase') ? 'selected' : '' ?>>Direct purchase</option>
            <option value="Customized dress" <?= ($order_type == 'Customized_dress') ? 'selected' : '' ?>>Customized dress</option>
        </select>

        <button type="submit" class="submit-btn">Place Order</button>
    </form>

    <!-- Order Summary -->
    <div class="summary">
        <h2>Order Summary</h2>
        <?php if (!empty($_SESSION['cart'])): ?>
            <?php foreach ($_SESSION['cart'] as $item): ?>
                <div class="order-item">
                    <div class="product-name">Product: <?php echo htmlspecialchars($item['name']); ?></div>
                    <div class="product-price">Price: $<?php echo htmlspecialchars($item['price']); ?></div>
                    <div>Quantity: <?php echo htmlspecialchars($item['quantity']); ?></div>
                </div>
            <?php endforeach; ?>
        <?php else: ?>
            <p>Your cart is empty.</p>
        <?php endif; ?>

        <div class="total-price">Total Price: $<?php echo $total_price; ?></div>
    </div>
</div>
<?php include('footer.php'); ?>

</body>
</html>

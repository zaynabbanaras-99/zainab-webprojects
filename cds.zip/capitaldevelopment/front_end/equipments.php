<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Advance Equipment - Capital Development Services</title>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <style>
        body {
            background-color: #f9f9f9;
            font-family: Arial, sans-serif;
        }
        h1 {
            font-weight: bold;
            color: #333;
        }
        /* Equipment Card Styling */
        .equipment-card {
            background-color: #fff8e5;
            border-left: 5px solid #f4c542;
            padding: 20px;
            border-radius: 5px;
            max-width: 800px;
            margin: auto;
        }
        .equipment-card ul {
            list-style: none;
            padding: 0;
            margin: 0;
        }
        .equipment-card li {
            padding-left: 28px;
            background: url('https://cdn-icons-png.flaticon.com/512/190/190411.png') no-repeat left center;
            background-size: 18px;
            margin-bottom: 10px;
            font-size: 1.05rem;
            color: #444;
        }
        footer {
            background-color: #222;
            color: white;
            padding: 15px 0;
            margin-top: 40px;
        }
        footer p {
            margin: 0;
        }
    </style>
</head>
<body>

<div class="container my-5">
    <h1 class="text-center mb-4">Fumigation / Hygiene - Advance Equipment</h1>
    <div class="equipment-card shadow-sm">
        <ul>
            <li>High performance Thermal Foggers</li>
            <li>Trijet Foggers</li>
            <li>Automatic Water Tank Cleaners</li>
            <li>Compression Sprayer</li>
            <li>Fumigation Chambers</li>
            <li>Solar Injector Machines</li>
            <li>Phosphine Meters / Gas Detector</li>
            <li>Full Face Mask / Respirators</li>
            <li>All Safety Equipment</li>
            <li>Heavy Duty Drilling Machines</li>
        </ul>
    </div>
</div>

<!-- FOOTER -->
<footer>
    <div class="container text-center">
        <p>&copy; <?php echo date('Y'); ?> Capital Development Services. All Rights Reserved.</p>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

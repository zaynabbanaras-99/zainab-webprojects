<?php include 'navbar.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Capital Development Service</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet" />
  <style>
    .hero-section {
      background-color: #444;
      color: white;
      padding: 100px 0;
      text-align: center;
    }
    .hero-section h1 {
      font-weight: bold;
      font-size: 2.8rem;
    }
    .hero-section p {
      font-size: 1.1rem;
      max-width: 700px;
      margin: 20px auto;
    }
    .btn-yellow {
      background-color: #f4c542;
      border: none;
      color: #000;
      font-weight: 600;
    }
    .btn-yellow:hover {
      background-color: #e4b62d;
    }
    .contact-section {
      background-color: #f8f9fa;
      padding: 40px 0;
      text-align: center;
      font-size: 1.1rem;
      font-weight: 500;
    }
    .contact-section a {
      color: #000;
      font-weight: bold;
      text-decoration: none;
    }
    .contact-section a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <!-- HERO SECTION -->
  <section class="hero-section">
    <div class="container">
      <h1>Professional Pest Control Services</h1>
      <p>Protect your property with our eco-friendly, effective termite solutions. Certified experts serving residential and commercial properties.</p>
      <h2>Since 2009</h2>
      <div class="d-flex justify-content-center gap-3 mt-4 flex-wrap">
        <a href="booking.php" class="btn btn-yellow px-4 py-2">Schedule Inspection</a>
        <a href="equipments.php" class="btn btn-outline-light px-4 py-2">Learn More</a>
        <a href="whycds.php" class="btn btn-yellow px-4 py-2">Why Capital Development Services</a>
      </div>
    </div>
  </section>


  <!-- FOOTER -->
  <?php include 'footer.php'; ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<?php 
include('navbar.php');

$conn = new mysqli("localhost", "root", "", "capital_development");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

$sql = "SELECT service_title, service_description FROM services ORDER BY service_id ASC";
$result = $conn->query($sql);

$images = [
    "insect.jpg",
    "termite.jpg",
    "bird.jpg",
    "rat.jpg",
    "tank.jpg",
    "warehouse.jpg",
    "ipm.jpg",
    "training.jpg"
];
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Our Services</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body { background: #0f1b2b; color: #fff; font-family: sans-serif; margin: 0; }
    .container { max-width: 1200px; margin: auto; padding: 40px; }
    .grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 25px; }
    .card { background: #1d2c47; border-radius: 10px; overflow: hidden; box-shadow: 0 5px 15px rgba(0,0,0,0.3); }
    .card img { width: 100%; height: 180px; object-fit: cover; }
    .card-body { padding: 20px; }
    .card h2 { margin: 0 0 10px 0; color: #fff; font-size: 20px; }
    .card p { font-size: 14px; color: #ccc; }

    /* Button styling */
    .btn-link {
      display: inline-block;
      background: #4CAF50;
      color: #fff;
      padding: 12px 20px;
      font-size: 16px;
      border: none;
      border-radius: 8px;
      cursor: pointer;
      transition: background 0.3s ease;
      text-decoration: none;
    }
    .btn-link:hover {
      background: #45a049;
      color: #fff;
    }
  </style>
</head>
<body>

<div class="container">
  <h1 style="text-align:center; margin-bottom: 30px;">Our Services</h1>
  <div class="grid">
    <?php
    if ($result && $result->num_rows > 0) {
        $i = 0;
        while ($i < count($images) && ($row = $result->fetch_assoc())) {
            $imageURL = "../images/" . $images[$i];
            echo '<div class="card">';
            echo '<img src="' . $imageURL . '" alt="Service Image">';
            echo '<div class="card-body">';
            echo '<h2>' . htmlspecialchars($row['service_title']) . '</h2>';
            echo '<p>' . nl2br(htmlspecialchars($row['service_description'])) . '</p>';
            echo '</div></div>';
            $i++;
        }
    } else {
        echo "<p>No services found.</p>";
    }
    $conn->close();
    ?>
  </div>
</div>

<!-- Hygiene Materials Button -->
<div class="container" style="text-align:center; margin-top: 40px;">
  <a href="hygiene_material.php" class="btn-link">View Hygiene Material</a>
</div>

<?php include('footer.php'); ?>
</body>
</html>

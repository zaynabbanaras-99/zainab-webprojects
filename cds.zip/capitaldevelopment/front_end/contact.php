<?php
include('../db_con.php'); // Corrected path

$successMessage = "";
$errorMessage = "";

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $message = trim($_POST['message']);

    if (!empty($name) && !empty($email) && !empty($message)) {
        $sql = "INSERT INTO contact (name, email, message) VALUES (?, ?, ?)";
        if ($stmt = $conn->prepare($sql)) {
            $stmt->bind_param("sss", $name, $email, $message);
            if ($stmt->execute()) {
                $successMessage = "Your message has been sent successfully!";
            } else {
                $errorMessage = "There was an error sending the message. Please try again.";
            }
            $stmt->close();
        }
    } else {
        $errorMessage = "All fields are required.";
    }

    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Contact Us</title>
  <style>
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        background-color: #f0f4f8;
        margin: 0;
        padding: 0;
        padding-top: 70px;
    }

    .navigation-bar {
        position: fixed;
        top: 0; left: 0;
        width: 100%;
        z-index: 1000;
    }

    header {
        background-color: white;
        padding: 20px;
        text-align: center;
        color: black;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
    }

    header h1 {
        color: #000000ff;
        margin: 0;
        font-size: 2.5rem;
    }

    header p {
        margin-top: 10px;
        font-size: 1.2rem;
    }

    main {
        padding: 40px;
        display: flex;
        flex-wrap: wrap;
        justify-content: center;
        gap: 20px;
    }

    .contact-form {
        background: white;
        padding: 30px;
        max-width: 600px;
        border-radius: 10px;
        box-shadow: 0 4px 15px rgba(0, 0, 0, 0.1);
        flex-basis: 100%;
    }

    .contact-form h2 {
        margin-bottom: 20px;
        color: #333;
    }

    label {
        display: block;
        font-size: 1rem;
        margin-bottom: 10px;
    }

    input, textarea {
        width: 100%;
        padding: 14px;
        margin-bottom: 20px;
        border: 1px solid #ccc;
        border-radius: 5px;
        font-size: 1rem;
    }

    textarea {
        height: 150px;
        resize: vertical;
    }

    button {
        background-color: #3719bdff;
        color: white;
        padding: 12px 20px;
        border: none;
        border-radius: 5px;
        cursor: pointer;
        font-size: 1rem;
        display: block;
        margin: 0 auto;
    }

    .notification {
        text-align: center;
        padding: 10px;
        font-weight: bold;
        color: white;
        margin-bottom: 20px;
    }

    .success {
        background-color: #4CAF50;
    }

    .error {
        background-color: #F44336;
    }

    @media (max-width: 768px) {
        main {
            padding: 20px;
        }
    }
  </style>
</head>
<body>

<!-- Navbar -->
<?php include('navbar.php'); ?>

<!-- Header -->
<header>
  <h1>Contact Us</h1>
  <p>Have questions or feedback? We're here to help!</p>
</header>

<!-- Contact Form -->
<main>
  <section class="contact-form">
    <h2>Send Us a Message</h2>

    <?php if (!empty($successMessage)): ?>
      <div class="notification success"><?php echo $successMessage; ?></div>
    <?php elseif (!empty($errorMessage)): ?>
      <div class="notification error"><?php echo $errorMessage; ?></div>
    <?php endif; ?>

    <form action="" method="POST">
      <label for="name">Your Name</label>
      <input type="text" name="name" required>

      <label for="email">Your Email</label>
      <input type="email" name="email" required>

      <label for="message">Message</label>
      <textarea name="message" required></textarea>

      <button type="submit">Send Message</button>
    </form>
  </section>
</main>

<!-- Footer -->
<?php include('footer.php'); ?>
</body>
</html>

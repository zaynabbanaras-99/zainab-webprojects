<?php
include('../connects.php');

// Initialize variables
$success = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Check if form data is set
    if (isset($_POST['variation_name'])) {
        $variation_name = $_POST['variation_name'];

        // Validate inputs
        if (!empty($variation_name)) {
            // Insert into the database
            $query = "INSERT INTO variations (variation_name) VALUES ('$variation_name')";
            $result = mysqli_query($conn, $query);

            if ($result) {
                $success = "Variation added successfully.";
            } else {
                $error = "Error adding variation.";
            }
        } else {
            $error = "Please enter a variation name.";
        }
    } else {
        $error = "";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Variations</title>
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }

        .container {
            width: 600px;
            padding: 40px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            text-align: left;
            border: 1px solid #ddd;
        }

        h1 {
            color: #970037;
            margin-bottom: 20px;
            font-weight: bold;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin: 10px 0 5px;
            color: #333;
            font-size: 16px;
        }

        input[type="text"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 15px;
        }

        button {
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px;
            cursor: pointer;
            font-size: 14px;
            width: 150px;
            margin: 0 auto;
            transition: background-color 0.3s ease;
        }

        button:hover {
            background-color: #85002a;
        }

        .message {
            text-align: center;
            font-size: 14px;
            margin-top: 15px;
        }

        .message.success {
            color: green;
        }

        .message.error {
            color: red;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="container">
        <h1>Add Variations</h1>

        <?php if (!empty($success)): ?>
            <div class="message success"><?php echo $success; ?></div>
        <?php endif; ?>

        <?php if (!empty($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <form action="add_variations.php" method="post">
            <label for="variation_name">Variation Name:</label>
            <input type="text" id="variation_name" name="variation_name" required>

            <button type="submit">Add Variation</button>
        </form>
    </div>
</body>
</html>

<?php
mysqli_close($conn); // Close database connection
?>

<?php
session_start();
include("../db_con.php");

// Check if admin is logged in
if (!isset($_SESSION['user_id']) || $_SESSION['user_type'] !== 'admin') {
    header("Location: ../authentication/signin.php");
    exit();
}

// Fetch admin details
$admin_id = $_SESSION['user_id'];
$sql = "SELECT username, email, user_type, created_at FROM users WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $admin_id);
$stmt->execute();
$stmt->bind_result($username, $email, $user_type, $created_at);
$stmt->fetch();
$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Profile - Wellness Journey</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #eef3f8;
            margin: 0;
            padding: 0;
        }

        .profile-container {
            max-width: 550px;
            margin: 60px auto;
            background-color: #ffffff;
            padding: 40px;
            border-radius: 16px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.1);
        }

        h2 {
            text-align: center;
            color: #002b5c;
            margin-bottom: 30px;
        }

        .profile-info {
            font-size: 16px;
            margin-bottom: 15px;
            color: #333;
        }

        .profile-info strong {
            width: 130px;
            display: inline-block;
            color: #555;
        }

        .button-group {
            margin-top: 30px;
            text-align: center;
        }

        .btn {
            display: inline-block;
            padding: 12px 22px;
            margin: 0 8px;
            background-color: #002b5c;
            color: white;
            font-size: 14px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            text-decoration: none;
            transition: background 0.3s ease;
        }

        .btn:hover {
            background-color: #003c80;
        }
    </style>
</head>
<body>
    <div class="profile-container">
        <h2>Admin Profile</h2>

        <div class="profile-info"><strong>Full Name:</strong> <?php echo htmlspecialchars($username); ?></div>
        <div class="profile-info"><strong>Email:</strong> <?php echo htmlspecialchars($email); ?></div>
        <div class="profile-info"><strong>Role:</strong> <?php echo htmlspecialchars(ucfirst($user_type)); ?></div>
        <div class="profile-info"><strong>Joined:</strong> <?php echo date("F j, Y", strtotime($created_at)); ?></div>

        <div class="button-group">
            <a class="btn" href="admin_side_navbar.php">nav bar</a>
            <a class="btn" href="../logout.php">Logout</a>
        </div>
    </div>
</body>
</html>

<?php
session_start();
include('admin_side_navbar.php');



// ✅ Database connection
$conn = new mysqli("localhost", "root", "", "capital_development");
if ($conn->connect_error) die("Connection failed: " . $conn->connect_error);

// ✅ Fetch bookings
$sql = "SELECT * FROM bookings ORDER BY created_at DESC";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Manage Bookings - Admin Panel</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background: #f5f5f5;
      margin: 0;
    }

    .container {
      max-width: 1200px;
      margin: 60px auto;
      background: white;
      padding: 30px;
      border-radius: 8px;
      box-shadow: 0 8px 16px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #0a4c74;
      margin-bottom: 30px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 14px;
    }

    th, td {
      border-bottom: 1px solid #ccc;
      padding: 12px;
      text-align: left;
    }

    th {
      background: #0a4c74;
      color: white;
    }

    tr:hover {
      background-color: #f9f9f9;
    }

    .delete-btn {
      color: red;
      text-decoration: none;
      font-weight: bold;
      cursor: pointer;
    }

    .success {
      color: green;
      text-align: center;
      margin-bottom: 20px;
    }

    @media (max-width: 768px) {
      table {
        font-size: 12px;
      }

      td {
        word-wrap: break-word;
      }
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Manage Bookings</h2>

  <?php if ($result && $result->num_rows > 0): ?>
    <table>
      <thead>
        <tr>
          <th>ID</th>
          <th>Name</th>
          <th>Email</th>
          <th>Phone</th>
          <th>Address</th>
          <th>Service</th>
          <th>Date</th>
          <th>Message</th>
          <th>Created</th>
      
        </tr>
      </thead>
      <tbody>
        <?php while ($row = $result->fetch_assoc()): ?>
          <tr id="row-<?= $row['booking_id'] ?>">
            <td><?= $row['booking_id'] ?></td>
            <td><?= htmlspecialchars($row['customer_name']) ?></td>
            <td><?= htmlspecialchars($row['email']) ?></td>
            <td><?= htmlspecialchars($row['phone']) ?></td>
            <td><?= htmlspecialchars($row['address']) ?></td>
            <td><?= htmlspecialchars($row['service_type']) ?></td>
            <td><?= htmlspecialchars($row['preferred_date']) ?></td>
            <td><?= nl2br(htmlspecialchars($row['message'])) ?></td>
            <td><?= $row['created_at'] ?></td>
           
          </tr>
        <?php endwhile; ?>
      </tbody>
    </table>
  <?php else: ?>
    <p>No bookings found.</p>
  <?php endif; ?>
</div>

<script>
  function deleteBooking(id) {
    if (confirm("Are you sure you want to delete this booking?")) {
      fetch("delete_booking.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "id=" + id
      })
      .then(response => response.text())
      .then(result => {
        if (result.trim() === "success") {
          document.getElementById("row-" + id).remove();
        } else {
          alert("Failed to delete booking: " + result);
        }
      })
      .catch(err => {
        alert("Error sending request: " + err);
      });
    }
  }
</script>

</body>
</html>

<?php
include('../connects.php'); // Include database connection

// Fetching order data from the order_placed table
$sql = "SELECT order_id, user_email,phone_no,full_name,payment_method_used, shipping_method, shipping_address, order_date FROM order_placed";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Orders</title>
    <style>
        .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

       
        h1 {
            text-align: center;
            color: #970037;
        }

        table {
            width: 60%;
            margin-right: 20px;
            border-collapse: collapse;
            margin: 15px auto; /* Center the table horizontally */
            font-size: 0.8em; 
            border: 2px solid black; 
        }

        th, td {
            padding: 8px; 
            text-align: center;
            border: 1px solid #ddd; 
        }

        th {
            background-color: #970037;
            color: white;
            border: 1px solid #ddd; 
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-buttons {
            display: flex;
            gap: 6px; 
        }

        .action-buttons a {
            text-decoration: none;
            padding: 5px 8px; 
            color: white;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }

        .action-buttons a:first-child {
            background-color: green; 
        }

        .action-buttons a:first-child:hover {
            background-color: darkgreen;
        }

        .action-buttons a:last-child {
            background-color: red; 
        }

        .action-buttons a:last-child:hover {
            background-color: darkred;
        }
    </style>
</head>

<body>
<?php include('sidebar.php'); ?>
   
        <h1>Manage Orders</h1>
        <table>
            <thead>
                <tr>
                    <th>Order ID</th>
                    <th>User Email</th>
                    <th>Full Name</th>
                    <th>Phone No</th>
                    <th>Payment Method</th>
                    <th>Shipping Method</th>
                    <th>Shipping Address</th>
                    <th>Order Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['order_id'] . "</td>";
                        echo "<td>" . $row['user_email'] . "</td>";
                        echo "<td>" . $row['full_name'] . "</td>";
                        echo "<td>" . $row['phone_no'] . "</td>";
                        echo "<td>" . $row['payment_method_used'] . "</td>";
                        echo "<td>" . $row['shipping_method'] . "</td>";
                        echo "<td>" . $row['shipping_address'] . "</td>";
                        echo "<td>" . $row['order_date'] . "</td>";
                        echo "<td class='action-buttons'>
                                <a href='edit_order.php?order_id=" . $row['order_id'] . "'>Edit</a>
                                <a href='delete_order.php?order_id=" . $row['order_id'] . "'>Delete</a>
                              </td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='9'>No orders found</td></tr>";
                }
                ?>
            </tbody>
        </table>

</body>

</html>

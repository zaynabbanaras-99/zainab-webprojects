<?php
include(__DIR__ . '/../db_con.php');
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../authentication/signin.php");
    exit();
}

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Sanitize and get values
    $name = trim($_POST['name']);
    $price = (int) $_POST['price'];
    $description = trim($_POST['description']);
    $category_id = (int) $_POST['category'];

    // Validate required fields
    if (empty($name) || empty($price) || empty($description) || empty($category_id)) {
        die("All fields are required.");
    }

    // Prepare MySQLi query
    $stmt = $conn->prepare("INSERT INTO product (name, price, description, category_id) VALUES (?, ?, ?, ?)");

    if (!$stmt) {
        die("Prepare failed: " . $conn->error);
    }

    // Bind parameters — s = string, i = integer
    $stmt->bind_param("sisi", $name, $price, $description, $category_id);

    // Execute
    if ($stmt->execute()) {
        header("Location: manage_product.php?success=1");
        exit();
    } else {
        die("Failed to insert product: " . $stmt->error);
    }

} else {
    echo "Invalid request method.";
}

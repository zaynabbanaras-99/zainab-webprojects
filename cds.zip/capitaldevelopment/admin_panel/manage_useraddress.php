<?php
include('../connects.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage User Addresses</title>
    <style>
            .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
    text-align: left;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            color: #333;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        h1 {
            text-align: center;
            color: #960037;
        }

        table {
            width: 50%;
            border-collapse: collapse;
            margin-top: 20px;
            margin: 0 auto;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #960037;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #f5e6e6;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
        <h1>Manage User Addresses</h1>
        <table>
            <tr>
                <th>Serial Number</th>
                <th>User Email</th>
                <th>Default Address</th>
            </tr>
            <?php
            // Update the SQL query to retrieve user_email and is_default
            $sql = "SELECT user_email, is_default FROM user_address";
            $result = mysqli_query($conn, $sql);

            // Check if the query was successful
            if ($result) {
                if (mysqli_num_rows($result) > 0) {
                    $serial_number = 1; // Initialize temporary serial number
                    while ($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $serial_number . "</td>"; // Display serial number
                        echo "<td>" . $row['user_email'] . "</td>";
                        echo "<td>" . ($row['is_default'] ? 'Yes' : 'No') . "</td>";
                        echo "</tr>";
                        $serial_number++; // Increment the serial number
                    }
                } else {
                    echo "<tr><td colspan='3'>No addresses found.</td></tr>";
                }
            } else {
                // Print MySQL error if query fails
                echo "<tr><td colspan='3'>Error: " . mysqli_error($conn) . "</td></tr>";
            }

            mysqli_close($conn);
            ?>
        </table>
</body>
</html>

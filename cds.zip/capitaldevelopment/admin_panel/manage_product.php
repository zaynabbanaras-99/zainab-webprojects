<?php
// ✅ Include the correct database connection file
include('../db_con.php');
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Products</title>
    <style>
        body {
            text-align: center;
            font-family: Arial, sans-serif;
            margin: 0;
            background-color: #f9f9f9;
        }
        table {
            width: 80%;
            border-collapse: collapse;
            margin: 40px auto;
            border: 2px solid black;
            background-color: white;
        }
        th, td {
            border: 1px solid black;
            padding: 10px;
        }
        th {
            background-color: #970037;
            color: white;
        }
        h1 {
            color: #970037;
            margin-top: 40px;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        button {
            padding: 6px 12px;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-product button {
            background-color: #970037;
            margin-bottom: 20px;
        }
        .update-button {
            background-color: green;
        }
        .delete-button {
            background-color: red;
        }
        .product-image {
            width: 60px;
            height: 60px;
            object-fit: cover;
            border-radius: 5px;
        }
    </style>
</head>
<body>
    <?php include('admin_side_navbar.php'); ?>

    <h1>Manage Products</h1>
    
    <div class="add-product">
        <form action="add_product.php" method="post">
            <button type="submit">Add Product</button>
        </form>
    </div>

    <table>
        <tr>
            <th>#</th>
            <th>Category Name</th>
            <th>Product Name</th>
            <th>Description</th>
            <th>Price</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>

        <?php
        // ✅ Fetch all categories
        $categories = mysqli_query($conn, "SELECT * FROM product_category");
        if (!$categories) {
            die("❌ Category query failed: " . mysqli_error($conn));
        }

        $serial = 1;

        while ($category = mysqli_fetch_assoc($categories)) {
            // ✅ Fetch products belonging to this category
            $products = mysqli_query($conn, "SELECT * FROM product WHERE category_id = {$category['category_id']}");
            if (!$products) {
                die("❌ Product query failed: " . mysqli_error($conn));
            }

            while ($product = mysqli_fetch_assoc($products)) {
                // ✅ Fetch product image
                $images = mysqli_query($conn, "SELECT * FROM product_images WHERE product_id = {$product['product_id']} LIMIT 1");
                if (!$images) {
                    die("❌ Image query failed: " . mysqli_error($conn));
                }

                $image = mysqli_fetch_assoc($images);
                $imagePath = isset($image['pro_img_name']) && !empty($image['pro_img_name'])
                    ? "../images/{$image['pro_img_name']}"
                    : "../images/no-image.png";

                echo "
                <tr>
                    <td>{$serial}</td>
                    <td>{$category['category_name']}</td>
                    <td>{$product['name']}</td>
                    <td>{$product['description']}</td>
                    <td>{$product['price']}</td>
                    <td><img src='{$imagePath}' class='product-image' alt='Product Image'></td>
                    <td class='action-buttons'>
                        <form action='update_product.php' method='get' style='display:inline;'>
                            <input type='hidden' name='product_id' value='{$product['product_id']}'>
                            <button type='submit' class='update-button'>Update</button>
                        </form>
                        <form action='' method='post' onsubmit='return confirm(\"Are you sure you want to delete this product?\");' style='display:inline;'>
                            <input type='hidden' name='id' value='{$product['product_id']}'>
                            <button type='submit' name='delete' class='delete-button'>Delete</button>
                        </form>
                    </td>
                </tr>";
                $serial++;
            }
        }

        // ✅ Handle product deletion
        if (isset($_POST['delete'])) {
            $id = intval($_POST['id']);
            mysqli_query($conn, "DELETE FROM product_images WHERE product_id = $id");
            mysqli_query($conn, "DELETE FROM product WHERE product_id = $id");
            header("Location: manage_product.php");
            exit();
        }
        ?>
    </table>
</body>
</html>

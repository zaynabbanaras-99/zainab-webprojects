<?php
session_start();


include('../db_con.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>Admin - View Contact Messages</title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>
  body {
    background: #f5f7fa;
    font-family: 'Poppins', sans-serif;
    margin: 0;
    padding: 0;
  }

  h2 {
    text-align: center;
    margin-top: 40px;
    color: #333;
  }

  table {
    width: 90%;
    margin: 40px auto;
    border-collapse: collapse;
    background: white;
    border-radius: 12px;
    overflow: hidden;
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
  }

  th, td {
    padding: 14px;
    text-align: left;
    border-bottom: 1px solid #ddd;
  }

  th {
    background: #970037;
    color: white;
  }

  tr:hover {
    background: #f1f1f1;
  }

  .delete-btn {
    background: #F44336;
    color: white;
    border: none;
    padding: 8px 12px;
    border-radius: 6px;
    cursor: pointer;
    font-size: 14px;
  }

  .delete-btn:hover {
    background: #d32f2f;
  }

  .no-records {
    text-align: center;
    color: #666;
    margin-top: 50px;
  }

  .back {
    display: block;
    text-align: center;
    margin-top: 20px;
  }

  .back a {
    text-decoration: none;
    background: #007bff;
    color: white;
    padding: 10px 20px;
    border-radius: 6px;
  }

  .back a:hover {
    background: #0056b3;
  }
</style>
</head>
<body>

<h2>Contact Messages</h2>

<table>
  <tr>
    <th>ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Message</th>
    <th>Date</th>
    <th>Action</th>
  </tr>

  <?php
  $result = $conn->query("SELECT * FROM contact ORDER BY id DESC");
  if ($result && $result->num_rows > 0) {
      while ($row = $result->fetch_assoc()) {
          echo "<tr>
                  <td>{$row['id']}</td>
                  <td>{$row['name']}</td>
                  <td>{$row['email']}</td>
                  <td>{$row['message']}</td>
                  <td>{$row['created_at']}</td>
                  <td><a href='delete_contact.php?id={$row['id']}' onclick=\"return confirm('Are you sure you want to delete this message?');\">
                        <button class='delete-btn'>Delete</button>
                      </a></td>
                </tr>";
      }
  } else {
      echo "<tr><td colspan='6' class='no-records'>No messages found</td></tr>";
  }
  ?>
</table>

<div class="back">
  <a href="admin_dashboard.php">← Back to Dashboard</a>
</div>

</body>
</html>

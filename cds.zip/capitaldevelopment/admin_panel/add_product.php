<?php
include(__DIR__ . '/../db_con.php'); // ✅ Always safe path
session_start();

// Admin login check

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Product - Admin Panel</title>
    <link rel="stylesheet" href="../styles.css"> <!-- Your custom stylesheet -->
    <style>
        .main-content {
            margin-left: 260px;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            max-width: 600px;
        }

        label {
            display: block;
            margin-top: 15px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
        }

        button {
            margin-top: 20px;
            padding: 10px 20px;
            background-color: #2c3e50;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        button:hover {
            background-color: #34495e;
        }
    </style>
</head>
<body>

<?php include('admin_side_navbar.php'); ?>

<div class="main-content">
    <h1>Add New Product</h1>

    <form action="save_product.php" method="POST" enctype="multipart/form-data">
        <label for="name">Product Name:</label>
        <input type="text" name="name" id="name" required>

        <label for="price">Price (PKR):</label>
        <input type="number" name="price" id="price" required>

        <label for="description">Description:</label>
        <textarea name="description" id="description" rows="5" required></textarea>

        <label for="category">Category:</label>
        <input type="text" name="category" id="category">

        <label for="image">Upload Image:</label>
        <input type="file" name="image" id="image">

        <button type="submit">Add Product</button>
    </form>
</div>

</body>
</html>

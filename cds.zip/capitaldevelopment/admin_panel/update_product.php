<?php
include('../connects.php');
ob_start();

$success = false;
$error = '';

if (isset($_GET['product_id'])) {
    $product_id = intval($_GET['product_id']);

    // Fetch product details
    $fetch_product = mysqli_query($conn, "SELECT * FROM product WHERE product_id='$product_id'");
    $product = mysqli_fetch_assoc($fetch_product);

    if (!$product) {
        $error = "Product not found.";
    } elseif (isset($_POST['submit'])) {
        // Get form values
        $category_id = intval($_POST['category_id']);
        $name = mysqli_real_escape_string($conn, $_POST['name']);
        $price = floatval($_POST['price']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);

        // Update query
        $query = "UPDATE product SET 
                    category_id = '$category_id', 
                    name = '$name', 
                    description = '$description', 
                    price = '$price' 
                  WHERE product_id = '$product_id'";
        
        $result = mysqli_query($conn, $query);

        if ($result) {
            $success = true;
        } else {
            $error = "Error: Unable to update product.";
        }
    }
} else {
    $error = "No product ID provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Product</title>
    <style>
          .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f4f2;
            margin: 0;
            padding: 0;
        }

        .form_container {
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 90%;
        }

        h1 {
            color: #970037;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            color: #333;
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        select, input[type="text"], input[type="number"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 100px;
            resize: none;
        }

        input[type="submit"] {
            background-color: #970037;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #b0634a;
        }

        .error {
            color: #970037;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }

        .success_message {
            color: #28a745;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="form_container">
        <h1>Update Product</h1>
        <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>

        <?php if (!$success && isset($product)): ?>
            <form method="post" action="">
                <label for="category_id">Select Category:</label>
                <select name="category_id" required>
                    <?php 
                    $fetch_categories = mysqli_query($conn, "SELECT * FROM product_category");
                    while ($row = mysqli_fetch_assoc($fetch_categories)) { 
                        $cat_id = $row['category_id'];
                        $cat_name = $row['category_name'];
                        ?>
                        <option value="<?php echo $cat_id; ?>" <?php echo ($product['category_id'] == $cat_id) ? 'selected' : ''; ?>>
                            <?php echo $cat_name; ?>
                        </option>
                    <?php } ?>
                </select>

                <label for="name">Product Name:</label>
                <input type="text" id="name" name="name" value="<?php echo $product['name']; ?>" required>

                <label for="price">Product Price:</label>
                <input type="number" step="0.01" name="price" value="<?php echo $product['price']; ?>" required>

                <label for="description">Product Description:</label>
                <textarea id="description" name="description" required><?php echo $product['description']; ?></textarea>

                <center><input type="submit" name="submit" value="Update Product"></center>
                
            </form>
        <?php elseif ($success): ?>
            <div class="success_message">
                Product updated successfully!
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

<?php
// Use a robust relative path to the DB connection file.
// This assumes this file is: capitaldevelopment/admin_panel/manage_category.php
// and db_con.php is: capitaldevelopment/db_con.php
$dbConPath = __DIR__ . '/../db_con.php';
if (!file_exists($dbConPath)) {
    die("Database connection file not found at: $dbConPath");
}
include($dbConPath);

// Ensure $conn exists and is a mysqli connection
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("Database connection (\$conn) is not available. Check db_con.php.");
}

// Handle form submission for deletion (POST)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete'])) {
    $id = intval($_POST['id']); // sanitize
    if ($id > 0) {
        // If you want to cascade delete related products/images, do it here.
        // Example (optional):
        // mysqli_query($conn, "DELETE FROM product_images WHERE product_id IN (SELECT product_id FROM product WHERE category_id = $id)");
        // mysqli_query($conn, "DELETE FROM product WHERE category_id = $id");

        $del = mysqli_query($conn, "DELETE FROM product_category WHERE category_id = $id");
        if (!$del) {
            die("Failed to delete category: " . mysqli_error($conn));
        }
    }
    header("Location: manage_category.php");
    exit();
}
?>
<!DOCTYPE html>
<html>
<head>
    <title>Manage Categories</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #970037;
            margin-bottom: 20px;
            font-weight: bold;
        }
        table {
            width: 70%;
            border-collapse: collapse;
            margin: 0 auto;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #970037;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #e1e1e1;
        }
        .category-image {
            width: 80px; /* Fixed size for category images */
            height: 80px; /* Fixed size for category images */
            object-fit: cover;
            border-radius: 5px;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
        }
        .action-buttons button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }
        .update-button {
            background-color: #28a745;
            color: white;
        }
        .update-button:hover {
            background-color: #218838;
        }
        .delete-button {
            background-color: #dc3545;
            color: white;
        }
        .delete-button:hover {
            background-color: #c82333;
        }
        .add-category {
            margin-bottom: 20px;
            text-align: center;
        }
        .add-category button {
            padding: 10px 20px;
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }
        .add-category button:hover {
            background-color: #7c002c;
        }
    </style>
</head>
<body>
<?php
// include admin navbar if file exists; don't fatal if missing
$navPath = __DIR__ . '/admin_side_navbar.php';
if (file_exists($navPath)) {
    include($navPath);
}
?>
    <h1>Manage Categories</h1>
    
    <div class="add-category">
        <form action="add_category.php" method="post">
            <button type="submit">Add Category</button>
        </form>
    </div>

    <table>
        <tr>
            <th>#</th>
            <th>Category Name</th>
            <th>Description</th>
            <th>Image</th>
            <th>Actions</th>
        </tr>
        <?php
        // Fetch categories with error handling
        $q = "SELECT * FROM product_category";
        $categories = mysqli_query($conn, $q);
        if (!$categories) {
            die("Category query failed: " . mysqli_error($conn));
        }

        $serial = 1;
        $imagesFolder = '../images'; // adjust if your images folder location differs
        $defaultImage = $imagesFolder . '/no-image.png'; // make sure this file exists

        while ($category = mysqli_fetch_assoc($categories)) {
            // Safe image path and fallback
            $imgName = isset($category['image']) && !empty($category['image']) ? $category['image'] : null;
            $imgPath = $imgName && file_exists(__DIR__ . '/../images/' . $imgName) ? "{$imagesFolder}/{$imgName}" : $defaultImage;

            // Escape output to avoid XSS
            $catName = htmlspecialchars($category['category_name']);
            $desc = htmlspecialchars($category['description']);
            $catId = intval($category['category_id']);

            echo "<tr>
                    <td>{$serial}</td>
                    <td>{$catName}</td>
                    <td>{$desc}</td>
                    <td><img src='{$imgPath}' alt='Category Image' class='category-image'></td>
                    <td class='action-buttons'>
                        <form action='update_category.php' method='get' style='display:inline;'>
                            <input type='hidden' name='category_id' value='{$catId}'>
                            <button type='submit' class='update-button'>Update</button>
                        </form>
                        <form action='' method='post' onsubmit='return confirm(\"Are you sure you want to delete this category?\");' style='display:inline;'>
                            <input type='hidden' name='id' value='{$catId}'>
                            <button type='submit' name='delete' class='delete-button'>Delete</button>
                        </form>
                    </td>
                  </tr>";
            $serial++;
        }
        ?>
    </table>
</body>
</html>

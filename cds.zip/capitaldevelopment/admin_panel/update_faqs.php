<?php
include('../connects.php');
ob_start();

$success = false;
$error = '';

if (isset($_GET['faq_id'])) {
    $faq_id = intval($_GET['faq_id']);

    // Fetch FAQ details
    $fetch_faq = mysqli_query($conn, "SELECT * FROM faq WHERE faq_id='$faq_id'");
    $faq = mysqli_fetch_assoc($fetch_faq);

    if (!$faq) {
        $error = "FAQ not found.";
    } elseif (isset($_POST['submit'])) {
        // Get form values
        $question = mysqli_real_escape_string($conn, $_POST['question']);
        $answer = mysqli_real_escape_string($conn, $_POST['answer']);

        // Update query
        $query = "UPDATE faq SET 
                    question = '$question', 
                    answer = '$answer' 
                  WHERE faq_id = '$faq_id'";

        $result = mysqli_query($conn, $query);

        if ($result) {
            $success = true;
        } else {
            $error = "Error: Unable to update FAQ.";
        }
    }
} else {
    $error = "No FAQ ID provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update FAQ</title>
    <style>
        /* Sidebar Style */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }

        /* General Body Style */
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f4f2;
            margin: 0;
            padding: 0;
        }

        /* Form Container Style */
        .form_container {
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 90%;
            margin-top: 50px;
        }

        h1 {
            color: #970037;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            color: #333;
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        select, input[type="text"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 100px;
            resize: none;
        }

        input[type="submit"] {
            background-color: #970037;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #b0634a;
        }

        /* Error Message Style */
        .error {
            color: #970037;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }

        /* Success Message Style */
        .success_message {
            color: #28a745;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }

        /* Button Centering */
        .center-button {
            display: flex;
            justify-content: center;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="form_container">
        <h1>Update FAQ</h1>
        <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>

        <?php if (!$success && isset($faq)): ?>
            <form method="post" action="">
                <label for="question">Question:</label>
                <input type="text" id="question" name="question" value="<?php echo $faq['question']; ?>" required>

                <label for="answer">Answer:</label>
                <textarea id="answer" name="answer" required><?php echo $faq['answer']; ?></textarea>

                <div class="center-button">
                    <input type="submit" name="submit" value="Update FAQ">
                </div>
            </form>
        <?php elseif ($success): ?>
            <div class="success_message">
                FAQ updated successfully!
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

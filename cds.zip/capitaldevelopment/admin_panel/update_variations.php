<?php
include('../connects.php');

// Check if variation_id is passed in the URL (POST method)
if (isset($_POST['id'])) {
    $variation_id = $_POST['id'];

    // Fetch the current variation data based on the variation_id
    $query = "SELECT * FROM variations WHERE variation_id = $variation_id";
    $result = mysqli_query($conn, $query);

    if ($result) {
        $variation = mysqli_fetch_assoc($result);
        if (!$variation) {
            echo "<p>Variation not found.</p>";
            exit();
        }
    } else {
        echo "<p>Error fetching variation: " . mysqli_error($conn) . "</p>";
        exit();
    }
} else {
    echo "<p>No variation ID passed.</p>";
    exit();
}

// Update the variation name in the database when the form is submitted
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['variation_name'])) {
    $new_variation_name = mysqli_real_escape_string($conn, $_POST['variation_name']);

    // Update query
    $update_query = "UPDATE variations SET variation_name = '$new_variation_name' WHERE variation_id = $variation_id";
    
    if (mysqli_query($conn, $update_query)) {
        echo "<p class='success'>Variation updated successfully!</p>";
        header("Location: manage_variations.php"); // Redirect to the variations page after update
        exit();
    } else {
        echo "<p class='error'>Error updating variation: " . mysqli_error($conn) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Variation</title>
    <style>
         .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            text-align: center;
        }
        .container {
            width: 35%;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #970037;
        }
        input[type="text"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border-radius: 5px;
            border: 1px solid #ddd;
        }
        input[type="submit"] {
            background-color: #970037;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
        }
        input[type="submit"]:hover {
            background-color: #75002b;
        }
        .error {
            color: red;
        }
        .success {
            color: green;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="container">
        <h1>Update Variation Name</h1>
        <form action="update_variations.php" method="POST">
            <input type="hidden" name="id" value="<?php echo $variation['variation_id']; ?>">
            <label for="variation_name">Variation Name:</label>
            <input type="text" id="variation_name" name="variation_name" value="<?php echo $variation['variation_name']; ?>" required>
            <input type="submit" value="Update Variation">
        </form>
    </div>

</body>
</html>

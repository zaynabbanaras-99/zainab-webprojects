<?php
// ✅ Safe and consistent DB connection include
// Assuming this file is in: capitaldevelopment/admin_panel/manage_contacts.php
// and connects.php is in: capitaldevelopment/connects.php
$dbConPath = __DIR__ . '/../db_con.php';

if (!file_exists($dbConPath)) {
    die("❌ Database connection file not found at: $dbConPath");
}
include($dbConPath);

// ✅ Ensure connection exists
if (!isset($conn) || !($conn instanceof mysqli)) {
    die("❌ Database connection (\$conn) not established. Check connects.php.");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Contacts</title>
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f9;
            margin: 0;
            padding: 20px;
            color: #333;
        }
        h1 {
            text-align: center;
            color: #960037;
            margin-bottom: 20px;
        }
        table {
            width: 70%;
            margin: 0 auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        table, th, td {
            border: 1px solid #ddd;
        }
        th, td {
            padding: 12px;
            text-align: left;
        }
        th {
            background-color: #960037;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        tr:hover {
            background-color: #f5e6e6;
        }
    </style>
</head>
<body>
<?php
// ✅ Include sidebar safely
$navPath = __DIR__ . '/admin_side_navbar.php';
if (file_exists($navPath)) {
    include($navPath);
}
?>

    <h1>Manage Contacts</h1>
    <table>
        <tr>
            <th>Contact ID</th>
            <th>Name</th>
            <th>Email</th>
            <th>Message</th>
        </tr>
        <?php
        // ✅ Query contacts with error handling
        $sql = "SELECT contact_id, name, email, message FROM contact";
        $result = mysqli_query($conn, $sql);

        if (!$result) {
            echo "<tr><td colspan='4' style='color:red;'>Query failed: " . htmlspecialchars(mysqli_error($conn)) . "</td></tr>";
        } elseif (mysqli_num_rows($result) > 0) {
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>
                        <td>{$row['contact_id']}</td>
                        <td>" . htmlspecialchars($row['name']) . "</td>
                        <td>" . htmlspecialchars($row['email']) . "</td>
                        <td>" . htmlspecialchars($row['message']) . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='4'>No contacts found.</td></tr>";
        }

        // ✅ Close connection cleanly
        mysqli_close($conn);
        ?>
    </table>
</body>
</html>

<?php
include('../connects.php');

// Initialize variables
$variation_id = '';
$current_variation_type = '';
$current_option_image = '';
$current_additional_cost = '';
$current_description = '';
$current_product_id = '';

// Check if the variation_id is set in the URL or POST request
if (isset($_GET['id'])) {
    $variation_id = $_GET['id'];

    // Fetch the current variation details based on the variation_id
    $query = "SELECT * FROM `variation-options` WHERE variation_id = $variation_id";
    $result = mysqli_query($conn, $query);

    if (!$result) {
        die('Error fetching variation: ' . mysqli_error($conn));
    }

    $variation = mysqli_fetch_assoc($result);
    if ($variation) {
        $current_variation_type = $variation['variation_type'];
        $current_option_image = $variation['option_image'];
        $current_additional_cost = $variation['additional_cost'];
        $current_description = $variation['description'];
        $current_product_id = $variation['product_id'];
    }
}

// Process the form submission when the form is submitted (POST request)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['id'])) {
    // Get form data to update variation
    $variation_id = $_POST['id'];
    $variation_type = $_POST['variation_type'];
    $additional_cost = $_POST['additional_cost'];
    $description = $_POST['description'];
    $product_id = $_POST['product_id'];

    // Check if a new image is uploaded
    if ($_FILES['option_image']['name']) {
        $image_name = $_FILES['option_image']['name'];
        $target_dir = "../images/";
        $target_file = $target_dir . basename($image_name);

        if (move_uploaded_file($_FILES["option_image"]["tmp_name"], $target_file)) {
            $option_image = $image_name;
        } else {
            echo "<p class='error'>Error uploading the image.</p>";
            exit();
        }
    } else {
        // If no new image is uploaded, use the current one
        $option_image = $current_option_image;
    }

    // Update the variation in the database
    $update_query = "UPDATE `variation-options` 
                     SET variation_type = '$variation_type',
                         option_image = '$option_image',
                         additional_cost = '$additional_cost',
                         description = '$description',
                         product_id = '$product_id'
                     WHERE variation_id = $variation_id";

    if (mysqli_query($conn, $update_query)) {
        echo "<p class='success'>Variation updated successfully!</p>";
    } else {
        echo "<p class='error'>Error updating variation: " . mysqli_error($conn) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Variation Option</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        .container {
            width: 50%;
            margin: 0 auto;
            padding: 20px;
            background-color: #f9f9f9;
            border-radius: 5px;
            box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #970037;
            text-align: center;
        }

        input, textarea, select {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        input[type="submit"] {
            background-color: #970037;
            color: white;
            border: none;
            cursor: pointer;
            padding: 10px 20px;
            text-align: center;
        }

        input[type="submit"]:hover {
            background-color: #75002b;
        }

        .error {
            color: red;
            text-align: center;
        }

        .success {
            color: green;
            text-align: center;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>

<div class="container">
    <h1>Update Variation Option</h1>
    <form method="POST" enctype="multipart/form-data" action="">
        <input type="hidden" name="id" value="<?php echo htmlspecialchars($variation_id); ?>">

        <label for="variation_type">Variation Type:</label>
        <input type="text" id="variation_type" name="variation_type" value="<?php echo htmlspecialchars($current_variation_type); ?>" required>

        <label for="option_image">Option Image (upload if you want to change):</label>
        <input type="file" id="option_image" name="option_image">

        <label for="additional_cost">Additional Cost:</label>
        <input type="text" id="additional_cost" name="additional_cost" value="<?php echo htmlspecialchars($current_additional_cost); ?>" required>

        <label for="description">Description:</label>
        <textarea id="description" name="description" required><?php echo htmlspecialchars($current_description); ?></textarea>

        <label for="product_id">Product:</label>
        <select id="product_id" name="product_id" required>
            <?php
            // Fetch all products to populate the dropdown
            $product_query = "SELECT * FROM product";
            $product_result = mysqli_query($conn, $product_query);

            while ($product = mysqli_fetch_assoc($product_result)) {
                $selected = ($product['product_id'] == $current_product_id) ? 'selected' : '';
                echo "<option value='{$product['product_id']}' $selected>{$product['name']}</option>";
            }
            ?>
        </select>

        <input type="submit" value="Update Variation">
    </form>
</div>

</body>
</html>

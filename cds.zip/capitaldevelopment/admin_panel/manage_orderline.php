<?php
include('../connects.php'); // Include your database connection file

$query = "SELECT * FROM orders_line"; // Fetch all records from the orders_line table
$result = mysqli_query($conn, $query);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Order Line</title>
    <style>
                          .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
    text-align: left;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            padding: 20px;
            margin: 0;
        }

        h1 {
            text-align: center;
            color: #970037;
            margin-bottom: 20px;
        }

        table {
            width: 50%; /* Reduced width to make the table more compact */
            margin: 20px auto;
            border-collapse: collapse;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border: 1px solid black; /* Add black border around the table */
        }

        th, td {
            padding: 8px; /* Reduced padding to compress rows */
            text-align: left;
            border: 1px solid black; /* Add border between columns */
            font-size: 14px; /* Reduced font size for a more compact look */
        }

        th {
            background-color: #970037;
            color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-buttons {
            display: flex;
            gap: 5px; /* Space between buttons */
            justify-content: center; /* Center align buttons horizontally */
        }

        .action-buttons a {
            text-decoration: none;
            color: white;
            padding: 6px 10px; /* Reduced padding to make buttons more compact */
            border-radius: 4px;
            display: inline-block;
            width: 55px; /* Adjusted button width */
            text-align: center; /* Center align text within buttons */
            font-size: 12px; /* Reduced font size to fit in smaller buttons */
        }

        .action-buttons .update-btn {
            background-color: #28a745; /* Green color for update */
        }

        .action-buttons .delete-btn {
            background-color: #dc3545; /* Red color for delete */
        }

        .action-buttons .update-btn:hover {
            background-color: #218838; /* Darker green on hover */
        }

        .action-buttons .delete-btn:hover {
            background-color: #c82333; /* Darker red on hover */
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
<h1>Manage Order Line</h1>

<table>
    <tr>
        <th>Order Line ID</th>
        <th>Order ID</th>
        <th>Quantity</th>
        <th>Price</th>
        <th>Action</th>
    </tr>
    <?php 
    while($row = mysqli_fetch_assoc($result)) {
        $order_line_id = $row['order_line_id'];
        $order_id = $row['order_id'];
        $quantity = $row['quantity'];
        $price = $row['price'];
        ?>
        <tr>
            <td><?php echo $order_line_id; ?></td>
            <td><?php echo $order_id; ?></td>
            <td><?php echo $quantity; ?></td>
            <td><?php echo $price; ?></td>
            <td class="action-buttons">
                <a href="update_orderline.php?order_line_id=<?php echo $order_line_id; ?>" class="update-btn">UPDATE</a>
                <a href="manage_orderline.php?order_line_id=<?php echo $order_line_id; ?>" class="delete-btn">DELETE</a>
            </td>
        </tr>
        <?php
    }
    ?>
</table>

</body>
</html>

<?php
if(isset($_GET['order_line_id'])) {
    $del_id = $_GET['order_line_id'];
    $del_query = mysqli_query($conn, "DELETE FROM orders_line WHERE order_line_id='$del_id'");
    if($del_query) {
        header('Location: manage_orderline.php');
    } else {
        echo "Failed to delete the order line.";
    }
}
?>

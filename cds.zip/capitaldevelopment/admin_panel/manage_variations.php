<?php
include('../connects.php'); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Variations</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            text-align: center;
        }
        table {
            width: 40%;
            border-collapse: collapse;
            margin: 0 auto;
            border: 2px solid black;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #970037;
            color: white;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        button {
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-variation button {
            background-color: #970037;
            margin-bottom: 20px;
        }
        .add-variation {
            text-align: center;
        }
        .update-button {
            background-color: green;
        }
        .delete-button {
            background-color: red;
        }
        h1 {
            color: #970037;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <h1>Manage Variations</h1>
    
    <div class="add-variation">
        <form action="add_variations.php" method="post">
            <button type="submit">Add Variation</button>
        </form>
    </div>

    <table>
        <tr>
            <th>#</th>
            <th>Variation Name</th>
            <th>Actions</th>
        </tr>
        <?php
        // Fetch variations data from the variations table
        $variations = mysqli_query($conn, "SELECT * FROM variations");
        $serial = 1; // Initialize serial number

        while ($variation = mysqli_fetch_assoc($variations)) {
            echo "<tr>
                    <td>{$serial}</td>
                    <td>{$variation['variation_name']}</td>
                    <td class='action-buttons'>
                        <form action='update_variations.php' method='post'>
                            <input type='hidden' name='id' value='{$variation['variation_id']}'>
                            <button type='submit' class='update-button'>Update</button>
                        </form>
                        <form action='' method='post' onsubmit='return confirm(\"Are you sure you want to delete this variation?\");'>
                            <input type='hidden' name='id' value='{$variation['variation_id']}'>
                            <button type='submit' name='delete' class='delete-button'>Delete</button>
                        </form>
                    </td>
                  </tr>";
            $serial++; // Increment serial number
        }

        // Handle the delete action
        if (isset($_POST['delete'])) {
            $id = $_POST['id'];
            mysqli_query($conn, "DELETE FROM variations WHERE variation_id = $id");
            header("Location: manage_variations.php"); // Refresh the page after deletion
            exit();
        }
        ?>
    </table>
</body>
</html>

<?php
session_start();


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Capital Development Services</title>
    <link rel="stylesheet" href="../style.css"> <!-- Keep your existing CSS here -->
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
        }

        .admin-container {
            max-width: 1000px;
            margin: auto;
            padding: 20px;
        }

        .admin-header {
            background-color: #333;
            color: #fff;
            padding: 15px 25px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .admin-links a {
            display: inline-block;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin: 8px;
            border-radius: 5px;
            text-decoration: none;
        }

        .admin-links a:hover {
            background-color: #0056b3;
        }

        .logout-button {
            float: right;
            background-color: crimson !important;
        }

        .section {
            background-color: #ffffff;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>
    
<?php include('admin_side_navbar.php'); ?>

<div class="admin-container">
    <div class="admin-header">
        <h2>Welcome, Admin</h2>
       

</body>
</html>

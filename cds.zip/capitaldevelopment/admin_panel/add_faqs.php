<?php
include('../connects.php'); // Database connection

$message = ''; // Initialize message variable

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Validate if the form fields are set
    $question = isset($_POST['question']) ? $_POST['question'] : null;
    $answer = isset($_POST['answer']) ? $_POST['answer'] : null;

    // Validate if fields are not empty
    if ($question && $answer) {
        // Escape special characters in the inputs
        $question = mysqli_real_escape_string($conn, $question);
        $answer = mysqli_real_escape_string($conn, $answer);

        // Use a prepared statement to insert FAQ data into the database
        $query = "INSERT INTO faq (question, answer) VALUES (?, ?)";
        $stmt = mysqli_prepare($conn, $query);

        if ($stmt) {
            // Bind the parameters to the prepared statement
            mysqli_stmt_bind_param($stmt, "ss", $question, $answer);

            // Execute the prepared statement
            if (mysqli_stmt_execute($stmt)) {
                $message = "FAQ added successfully!";
            } else {
                $message = "Error: " . mysqli_error($conn);
            }

            // Close the prepared statement
            mysqli_stmt_close($stmt);
        } else {
            $message = "Error preparing the statement: " . mysqli_error($conn);
        }
    } else {
        $message = "Please fill in both the question and the answer.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add FAQ</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #fff;
            padding: 40px;
            border: 1px solid #ddd;
            width: 600px;
            min-height: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: #970037;
            margin-bottom: 20px;
        }
        input, textarea, button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            width: 50%;
            background-color: #970037;
            color: white;
            border: none;
            padding: 12px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #70002a;
        }
        textarea {
            resize: vertical;
        }
        /* Message styling */
        .message {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            display: inline-block;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        .message p {
            margin: 0;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
<div class="form-container">
    <h2>Add FAQ</h2>
    <form action="add_faqs.php" method="post">
        <textarea name="question" placeholder="Enter Question" rows="3" required></textarea>
        <textarea name="answer" placeholder="Enter Answer" rows="5" required></textarea>
        <button type="submit">Add FAQ</button>
    </form>

    <!-- Display success or error message below the form -->
    <?php if ($message): ?>
        <div class="message <?php echo strpos($message, 'successfully') ? '' : 'error'; ?>">
            <p><?php echo $message; ?></p>
        </div>
    <?php endif; ?>
</div>

</body>
</html>

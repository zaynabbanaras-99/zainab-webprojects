<?php
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../authentication/signin.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin Dashboard - Capital Development Services</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }

        .admin-container {
            max-width: 1000px;
            margin: 40px auto;
            padding: 20px;
        }

        .admin-header {
            background-color: #333;
            color: #fff;
            padding: 15px 25px;
            border-radius: 8px;
            margin-bottom: 20px;
        }

        .admin-header h2 {
            display: inline-block;
        }

        .logout-button {
            float: right;
            background-color: crimson;
            color: white;
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
        }

        .admin-links a {
            display: inline-block;
            background-color: #007bff;
            color: #fff;
            padding: 10px 20px;
            margin: 8px;
            border-radius: 5px;
            text-decoration: none;
        }

        .admin-links a:hover {
            background-color: #0056b3;
        }

        .section {
            background-color: #ffffff;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 6px rgba(0,0,0,0.1);
        }

        h3 {
            margin-top: 0;
        }
    </style>
</head>
<body>

<div class="admin-container">
    <div class="admin-header">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['admin_name']); ?></h2>
        <a class="logout-button" href="../authentication/Signout.php">Logout</a>
    </div>

    <div class="admin-links">
        <a href="manage_product.php">Manage Products</a>
        <a href="manage_messages.php">View Messages</a>
        <a href="manage_user.php">Manage Users</a>
    </div>

    <div class="section">
        <h3>Dashboard Overview</h3>
        <p>Manage your products, view messages, and handle user accounts all from here.</p>
    </div>
</div>

</body>
</html>

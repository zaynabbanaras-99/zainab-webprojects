<?php
include('../connects.php'); 
?>

<!DOCTYPE html>
<html>
<head>
    <title>Manage Variation Options</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            text-align: center;
        }
        table {
            width: 60%;
            border-collapse: collapse;
            margin: 0 auto;
            border: 2px solid black;
        }
        th, td {
            border: 1px solid black;
            padding: 8px;
        }
        th {
            background-color: #970037;
            color: white;
        }
        .action-buttons {
            display: flex;
            gap: 10px;
            justify-content: center;
        }
        button {
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        .add-variation button {
            background-color: #970037;
            margin-bottom: 20px;
        }
        .add-variation {
            text-align: center;
        }
        .update-button {
            background-color: green;
        }
        .delete-button {
            background-color: red;
        }
        .option-image {
            width: 50px;
            height: 50px;
            object-fit: cover;
        }
        h1 {
            color: #970037;
        }
        .no-data {
            font-size: 18px;
            color: #970037;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <h1>Manage Variation Options</h1>
    
    <div class="add-variation">
        <form action="add_variation_options.php" method="post">
            <button type="submit">Add Variation Option</button>
        </form>
    </div>

    <table>
        <tr>
            <th>#</th>
            <th>Variation Name</th>
            <th>Variation Type</th>
            <th>Product Name</th>
            <th>Image</th>
            <th>Additional Cost</th>
            <th>Description</th>
            <th>Actions</th>
        </tr>
        <?php
        // Correct query to fetch variation options (wrapped table name in backticks)
        $variations_query = "SELECT * FROM `variation-options`";
        $variations_result = mysqli_query($conn, $variations_query);

        if (!$variations_result) {
            die('Error with variations query: ' . mysqli_error($conn));
        }

        // Check if there are any results
        if (mysqli_num_rows($variations_result) > 0) {
            while ($variation = mysqli_fetch_assoc($variations_result)) {
                // Fetch the product name for the product_id from the product table
                $product_query = "SELECT name FROM product WHERE product_id = {$variation['product_id']}";
                $product_result = mysqli_query($conn, $product_query);
                if (!$product_result) {
                    die('Error with product query: ' . mysqli_error($conn));
                }
                $product_name = mysqli_fetch_assoc($product_result)['name'];

                // Fetch the variation name using variation_id from the variations table
                $variation_name_query = "SELECT variation_name FROM variations WHERE variation_id = {$variation['variation_id']}";
                $variation_name_result = mysqli_query($conn, $variation_name_query);
                if (!$variation_name_result) {
                    die('Error with variation name query: ' . mysqli_error($conn));
                }
                $variation_name = mysqli_fetch_assoc($variation_name_result)['variation_name'];

                // Displaying the fetched information, using option_id as serial number
                echo "<tr>
                        <td>{$variation['option_id']}</td>
                        <td>{$variation_name}</td>
                        <td>{$variation['variation_type']}</td>
                        <td>{$product_name}</td>
                        <td><img src='../images/{$variation['option_image']}' class='option-image' alt='Option Image'></td>
                        <td>{$variation['additional_cost']}</td>
                        <td>{$variation['description']}</td>
                        <td class='action-buttons'>
                            <form action='update_variation_options.php' method='post'>
                                <input type='hidden' name='id' value='{$variation['variation_id']}'>
                                <input type='hidden' name='variation_name' value='{$variation_name}'> <!-- Pass the variation_name -->
                                <button type='submit' class='update-button'>Update</button>
                            </form>
                            <form action='' method='post' onsubmit='return confirm(\"Are you sure you want to delete this variation option?\");'>
                                <input type='hidden' name='id' value='{$variation['variation_id']}'>
                                <button type='submit' name='delete' class='delete-button'>Delete</button>
                            </form>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='8' class='no-data'>No variation options available.</td></tr>";
        }

        // Handle deletion of variation options
        if (isset($_POST['delete'])) {
            $id = $_POST['id'];
            mysqli_query($conn, "DELETE FROM `variation-options` WHERE variation_id = $id");
            header("Location: manage_variation_options.php");
            exit();
        }
        ?>
    </table>
</body>
</html>

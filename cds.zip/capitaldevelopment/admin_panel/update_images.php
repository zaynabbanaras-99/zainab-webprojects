<?php
include('../connects.php'); 

// Ensure the ID is provided in the URL
if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Fetch the current image data based on the ID
    $sql = "SELECT product_images.pro_img_name, product_images.product_id, product.name 
            FROM product_images 
            JOIN product ON product_images.product_id = product.product_id 
            WHERE product_images.id = '$id'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) > 0) {
        $row = mysqli_fetch_assoc($result);
        $current_pro_img_name = $row['pro_img_name'];
        $current_product_id = $row['product_id'];
        $current_name = $row['name'];
    } else {
        echo "Image not found.";
        exit();
    }
} else {
    echo "No image ID provided.";
    exit();
}

// Handle the form submission for updating the image data
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $pro_img_name = $_POST["pro_img_name"];
    $name = $_POST["name"];
    $image_file = $_FILES["image_file"]["name"];
    
    // If a new image file is uploaded, update the file
    if (!empty($image_file)) {
        $target_dir = "product_images/";
        $target_file = $target_dir . basename($image_file);

        if (move_uploaded_file($_FILES["image_file"]["tmp_name"], $target_file)) {
            // Update query with new image
            $sql = "UPDATE product_images 
                    SET pro_img_name='$image_file' 
                    WHERE id='$id'";
        } else {
            echo "<p class='error'>Error uploading the file.</p>";
            exit();
        }
    } else {
        // Update query without changing the image
        $sql = "UPDATE product_images 
                SET pro_img_name='$pro_img_name' 
                WHERE id='$id'";
    }

    // Update the product name in the product table
    $sql_update_name = "UPDATE product 
                        SET name='$name' 
                        WHERE product_id='$current_product_id'";

    if (mysqli_query($conn, $sql) && mysqli_query($conn, $sql_update_name)) {
        echo "<p>Image updated successfully!</p>";
    } else {
        echo "<p class='error'>Error updating image: " . mysqli_error($conn) . "</p>";
    }
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Update Image</title>
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .container {
            background-color: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            width: 400px;
            box-sizing: border-box;
        }

        h1 {
            color: #970037;
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-bottom: 8px;
            color: #333;
            font-weight: bold;
        }

        input[type="text"], input[type="file"] {
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
            width: 100%;
            box-sizing: border-box;
        }

        input[type="submit"] {
            background-color: #970037;
            color: white;
            padding: 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            width: 70%;
            align-self: center;
            margin: 0 auto;
        }

        input[type="submit"]:hover {
            background-color: #75002b;
        }

        p {
            text-align: center;
            color: green;
        }

        .error {
            text-align: center;
            color: red;
        }

        .current-image {
            text-align: center;
            margin-bottom: 20px;
        }

        .current-image img {
            max-width: 100%;
            border-radius: 4px;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="container">
        <h1>Update Image</h1>

        <div class="current-image">
            <p>Current Image:</p>
            <img src="product_images/<?php echo $current_pro_img_name; ?>" alt="Current Image">
        </div>

        <form method="POST" enctype="multipart/form-data" action="">
            <label for="pro_img_name">Image Name:</label>
            <input type="text" id="pro_img_name" name="pro_img_name" value="<?php echo $current_pro_img_name; ?>" required>

            <label for="name">Product Name:</label>
            <input type="text" id="name" name="name" value="<?php echo $current_name; ?>" required>

            <label>Select New Image File (if you want to change it):</label>
            <input type="file" name="image_file">

            <input type="submit" value="Update Image">
        </form>
    </div>
</body>
</html>

<?php
include('../db_con.php');
session_start();
if (!isset($_SESSION['admin_logged_in'])) {
    header("Location: ../authentication/signin.php");
    exit();
}

// Fetch all users
$query = "SELECT * FROM users";
$stmt = $conn->prepare($query);
$stmt->execute();
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Encode users as JSON for JavaScript
echo "<script>const userData = " . json_encode($users) . ";</script>";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel - User Management</title>
    <link rel="stylesheet" href="styles.css"> <!-- Your main stylesheet -->
    <style>
        .main-content {
            margin-left: 260px;
            padding: 20px;
        }

        h1 {
            margin-bottom: 20px;
            font-size: 24px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }

        th, td {
            padding: 12px;
            border: 1px solid #ccc;
            text-align: left;
        }

        th {
            background-color: #2c3e50;
            color: white;
        }

        a {
            color: #3498db;
            text-decoration: none;
        }

        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<?php include('admin_side_navbar.php'); ?>

<?php include('admin_side_navbar.php'); ?>

<div class="main-content">
    <section id="admin-panel">
        <h1>Admin Panel: User Management</h1>
        <table id="user-table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Recovery Stage</th>
                    <th>Goals</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <!-- Filled by JavaScript -->
            </tbody>
        </table>
    </section>
</div>

<script>
    // Use the userData variable from PHP
    const users = userData;
    const tableBody = document.querySelector('#user-table tbody');

    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.id}</td>
            <td>${user.name}</td>
            <td>${user.email}</td>
            <td>${user.recovery_stage || 'N/A'}</td>
            <td>${user.goals || 'N/A'}</td>
            <td>${user.role}</td>
            <td><a href="edit_user.php?id=${user.id}">Edit</a></td>
        `;
        tableBody.appendChild(row);
    });
</script>

</body>
</html>

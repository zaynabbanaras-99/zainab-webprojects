<?php
// Include database connection file
include('../connects.php'); 
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Image</title>
    <style>
         .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
    text-align: left;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 600px;
            padding: 40px;
            background-color: #fff;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            margin: 50px auto;
            text-align: left;
            border: 1px solid #ddd;
        }
        h1 {
            color: #970037;
            margin-bottom: 20px;
            font-weight: bold;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            color: #333;
            font-size: 16px;
        }
        input[type="text"],
        input[type="file"] {
            width: 100%;
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 14px;
            margin-bottom: 15px;
        }
        button {
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 4px;
            padding: 10px;
            cursor: pointer;
            font-size: 14px;
            width: 150px;
            margin: 0 auto;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #85002a;
        }
        .message {
            text-align: center;
            font-size: 14px;
            margin-top: 15px;
        }
        .message.success {
            color: green;
        }
        .message.error {
            color: red;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="container">
        <h1>Add Image</h1>
        <form method="POST" enctype="multipart/form-data" action="">

            <label for="product_id">Product ID:</label>
            <input type="text" id="product_id" name="product_id" required>

            <label for="image_file">Select Image File:</label>
            <input type="file" id="image_file" name="image_file" required>

            <button type="submit">Add Image</button>
        </form>

        <?php
        // Handle form submission
        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $product_id = $_POST["product_id"];
            $image_file = $_FILES["image_file"]["name"];
            $target_dir = "product_images/";

            // Check if product ID exists in the product table
            $check_product = "SELECT * FROM product WHERE product_id = '$product_id'";
            $product_result = mysqli_query($conn, $check_product);

            if (mysqli_num_rows($product_result) > 0) {
                // Product exists, proceed with image upload
                if (!is_dir($target_dir)) {
                    mkdir($target_dir, 0777, true); // Create directory if it doesn't exist
                }

                // Move uploaded image to target directory
                if (move_uploaded_file($_FILES['image_file']['tmp_name'], $target_dir . $image_file)) {
                    // Insert the image into product_images table
                    $sql = "INSERT INTO product_images (pro_img_name, product_id) VALUES ('$image_file', '$product_id')";

                    if (mysqli_query($conn, $sql)) {
                        echo "<p class='message success'>Image added successfully!</p>";
                    } else {
                        echo "<p class='message error'>Error adding image to database: " . mysqli_error($conn) . "</p>";
                    }
                } else {
                    echo "<p class='message error'>Error uploading image file.</p>";
                }
            } else {
                echo "<p class='message error'>Product ID does not exist in the product table.</p>";
            }
        }
        ?>
    </div>
</body>
</html>

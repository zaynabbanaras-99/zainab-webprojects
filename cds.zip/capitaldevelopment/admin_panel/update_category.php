<?php
include('../connects.php');
ob_start();

$success = false;
$error = '';

if (isset($_GET['category_id'])) {
    $category_id = intval($_GET['category_id']);

    // Fetch category details
    $fetch_category = mysqli_query($conn, "SELECT * FROM product_category WHERE category_id='$category_id'");
    $category = mysqli_fetch_assoc($fetch_category);

    if (!$category) {
        $error = "Category not found.";
    } elseif (isset($_POST['submit'])) {
        // Get form values
        $category_name = mysqli_real_escape_string($conn, $_POST['category_name']);
        $description = mysqli_real_escape_string($conn, $_POST['description']);
        $image = $_FILES['image']['name'];

        // Handle image upload
        if ($image) {
            $image_tmp = $_FILES['image']['tmp_name'];
            $image_path = 'uploads/' . $image;
            move_uploaded_file($image_tmp, $image_path);
        } else {
            $image_path = $category['image'];  // Keep the existing image if no new one is uploaded
        }

        // Update query
        $query = "UPDATE product_category SET 
                    category_name = '$category_name', 
                    description = '$description', 
                    image = '$image_path' 
                  WHERE category_id = '$category_id'";

        $result = mysqli_query($conn, $query);

        if ($result) {
            $success = true;
        } else {
            $error = "Error: Unable to update category.";
        }
    }
} else {
    $error = "No category ID provided.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Category</title>
    <style>
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            text-align: left;
        }
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f9f4f2;
            margin: 0;
            padding: 0;
        }

        .form_container {
            margin: auto;
            background-color: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            max-width: 800px;
            width: 90%;
        }

        h1 {
            color: #970037;
            text-align: center;
            margin-bottom: 20px;
        }

        label {
            color: #333;
            font-weight: bold;
            display: block;
            margin-bottom: 10px;
        }

        select, input[type="text"], input[type="file"], textarea {
            width: 100%;
            padding: 10px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 14px;
        }

        textarea {
            height: 100px;
            resize: none;
        }

        input[type="submit"] {
            background-color: #970037;
            color: #fff;
            border: none;
            padding: 10px 20px;
            cursor: pointer;
            border-radius: 5px;
            font-size: 16px;
        }

        input[type="submit"]:hover {
            background-color: #b0634a;
        }

        .error {
            color: #970037;
            font-weight: bold;
            text-align: center;
            margin-bottom: 10px;
        }

        .success_message {
            color: #28a745;
            font-weight: bold;
            text-align: center;
            margin-top: 20px;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="form_container">
        <h1>Update Category</h1>
        <?php if (!empty($error)) { echo "<p class='error'>$error</p>"; } ?>

        <?php if (!$success && isset($category)): ?>
            <form method="post" enctype="multipart/form-data">
                <label for="category_name">Category Name:</label>
                <input type="text" id="category_name" name="category_name" value="<?php echo $category['category_name']; ?>" required>

                <label for="description">Category Description:</label>
                <textarea id="description" name="description" required><?php echo $category['description']; ?></textarea>

                <label for="image">Category Image:</label>
                <input type="file" name="image" accept="image/*">

                <center><input type="submit" name="submit" value="Update Category"></center>
            </form>
        <?php elseif ($success): ?>
            <div class="success_message">
                Category updated successfully!
            </div>
        <?php endif; ?>
    </div>
</body>
</html>

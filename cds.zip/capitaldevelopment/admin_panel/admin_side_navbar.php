<!-- admin_side_navbar.php -->
<style>
    .sidebar {
        height: 100vh;
        width: 250px;
        position: fixed;
        background-color: #2c3e50;
        padding-top: 20px;
        color: white;
    }

    .sidebar h2 {
        text-align: center;
        margin-bottom: 30px;
        font-size: 24px;
        color: #ecf0f1;
    }

    .sidebar a {
        display: block;
        padding: 12px 20px;
        color: #ecf0f1;
        text-decoration: none;
        transition: 0.3s;
    }

    .sidebar a:hover {
        background-color: #34495e;
    }

    .logout {
        position: absolute;
        bottom: 20px;
        width: 100%;
    }
</style>

<div class="sidebar">
    <h2>Admin Panel</h2>
 

     <a href="manage_bookings.php">Manage Bookings</a>

    <a href="manage_contacts.php">User Messages</a>
    <a href="manage_user_feedback.php">User Feedback</a>
  
</div>

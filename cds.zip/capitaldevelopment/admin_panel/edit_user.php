<?php
include('../db_con.php');

// Enable error reporting for debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_GET['id'])) {
    $user_id = intval($_GET['id']);

    // Fetch user data from the database
    $sql = "SELECT id, username, email, user_type FROM users WHERE id = ?";
    $stmt = $conn->prepare($sql);

    if (!$stmt) {
        die("SQL error: " . $conn->error);
    }

    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $user = $result->fetch_assoc();

    if (!$user) {
        header('Location: user_management.php?error=UserNotFound');
        exit;
    }

    // Handle form submission to update user data
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $username = trim($_POST['username']);
        $email = trim($_POST['email']);
        $user_type = trim($_POST['user_type']);

        $valid_user_types = ['admin', 'user'];

        // Email validation
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error = "Invalid email format!";
        } elseif (!in_array($user_type, $valid_user_types)) {
            $error = "Invalid user role selected.";
        } elseif (!empty($username) && !empty($email) && !empty($user_type)) {
            // Prepare SQL query to update user
            $update_sql = "UPDATE users SET username = ?, email = ?, user_type = ? WHERE id = ?";
            $update_stmt = $conn->prepare($update_sql);
            $update_stmt->bind_param("sssi", $username, $email, $user_type, $user_id);

            if (!$update_stmt) {
                die("SQL error: " . $conn->error);
            }

            if ($update_stmt->execute()) {
                header('Location: user_management.php?success=UserUpdated');
                exit;
            } else {
                $error = "Error updating user: " . $update_stmt->error;
            }
        } else {
            $error = "All fields are required.";
        }
    }
} else {
    header('Location: user_management.php');
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Poppins', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            width: 90%;
            max-width: 600px;
            margin: auto;
            padding: 20px;
        }
        .form-container {
            padding: 20px;
            background-color: white;
            border-radius: 10px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .form-container input,
        .form-container select {
            width: 100%;
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            border: 1px solid #ccc;
        }
        .form-container button {
            background-color: #007BFF;
            color: white;
            padding: 12px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
            width: 100%;
        }
        .form-container button:hover {
            background-color: #0056b3;
        }
        .cancel-btn {
            background-color: #DC3545;
            padding: 12px;
            color: white;
            text-decoration: none;
            border-radius: 5px;
            display: inline-block;
            text-align: center;
            margin-top: 15px;
            width: 100%;
        }
        .cancel-btn:hover {
            background-color: #c82333;
        }
        .error-message {
            color: red;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Edit User</h1>
        <div class="form-container">
            <?php if (isset($error)) { echo "<p class='error-message'>$error</p>"; } ?>

            <form method="POST" action="">
                <input type="hidden" name="id" value="<?= htmlspecialchars($user['id']) ?>">

                <label for="username">Username:</label>
                <input type="text" name="username" id="username" value="<?= htmlspecialchars($user['username']) ?>" required>

                <label for="email">Email:</label>
                <input type="email" name="email" id="email" value="<?= htmlspecialchars($user['email']) ?>" required>

                <label for="user_type">User Type:</label>
                <select name="user_type" id="user_type" required>
                    <option value="admin" <?= $user['user_type'] === 'admin' ? 'selected' : '' ?>>Admin</option>
                    <option value="user" <?= $user['user_type'] === 'user' ? 'selected' : '' ?>>User</option>
                </select>

                <button type="submit">Update User</button>
            </form>
            <a href="user_management.php" class="cancel-btn">Cancel</a>
        </div>
    </div>
</body>
</html>

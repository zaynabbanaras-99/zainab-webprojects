<?php
include('../db_con.php');
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>User Management</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">

  <style>
    * { margin: 0; padding: 0; box-sizing: border-box; }

    body {
        font-family: 'Poppins', sans-serif;
        background-color: #f4f4f4;
    }

    .layout-wrapper {
      display: flex;
      height: 100vh;
      width: 100%;
      transition: all 0.3s ease;
    }

    .sidebar {
      width: 220px;
      background-color: #222;
      color: #fff;
      padding: 20px;
      transition: width 0.3s ease;
      height: 100%;
      position: fixed;
      left: 0;
      top: 0;
    }

    .sidebar.collapsed {
      width: 0;
      padding: 0;
      overflow: hidden;
    }

    .main-content {
      flex: 1;
      margin-left: 220px; /* Initially, make space for the sidebar */
      padding: 20px;
      transition: margin-left 0.3s ease;
    }

    .main-content.collapsed {
      margin-left: 0;
      padding-left: 20px;
    }

    .container {
      width: 90%;
      max-width: 1000px;
      margin: 40px auto;
      padding: 20px;
      background: white;
      border-radius: 10px;
      box-shadow: 0 0 15px rgba(0,0,0,0.1);
    }

    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      margin-bottom: 20px;
    }

    h1 {
      font-weight: 600;
      color: black;
    }

    .sort-container {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    select {
      padding: 8px;
      border: 1px solid #ddd;
      border-radius: 5px;
      font-size: 16px;
    }

    .btn {
      padding: 10px 15px;
      background-color: rgb(105, 109, 117);
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: 500;
      cursor: pointer;
      transition: background 0.3s;
      margin-bottom: 15px;
      display: inline-block;
    }

    .btn:hover {
      background-color: #094E63;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 15px;
      background: white;
      border-radius: 10px;
      overflow: hidden;
    }

    table th, table td {
      padding: 12px 15px;
      border: 1px solid #ddd;
      text-align: left;
    }

    table th {
      background-color: rgb(105, 109, 117);
      color: white;
    }

    table th a {
      color: white;
      text-decoration: none;
    }

    .action-buttons {
      display: flex;
      gap: 8px;
    }

    .edit-btn {
      background-color: rgba(3, 25, 74, 0.8);
      padding: 8px 12px;
      color: white;
      border-radius: 5px;
      font-size: 14px;
      font-weight: bold;
      text-decoration: none;
      transition: background-color 0.3s;
    }

    .edit-btn:hover {
      background-color: rgba(3, 25, 74, 1);
    }

    .delete-btn {
      background-color: #A83232;
      border: none;
      padding: 8px 12px;
      color: white;
      font-size: 14px;
      font-weight: bold;
      border-radius: 5px;
      cursor: pointer;
      transition: background-color 0.3s;
    }

    .delete-btn:hover {
      background-color: #871d1d;
    }

    @media (max-width: 600px) {
      .container { width: 100%; margin: 20px; padding: 15px; }
      table th, table td { font-size: 14px; }
    }
  </style>
</head>
<body>

<div class="layout-wrapper">
    <?php include('admin_side_navbar.php'); ?>

    <div class="main-content">
        <?php
        // Sorting setup
        $sort_by = isset($_GET['sort_by']) ? $_GET['sort_by'] : 'username';
        $order = isset($_GET['order']) ? $_GET['order'] : 'ASC';

        $valid_columns = ['username', 'email', 'user_type', 'current_time'];
        $sort_by = in_array($sort_by, $valid_columns) ? $sort_by : 'username';
        $order = ($order === 'DESC') ? 'DESC' : 'ASC';

        $sql = "SELECT id, username, email, user_type, current_time FROM users ORDER BY $sort_by $order";
        $result = $conn->query($sql);
        ?>

        <div class="container">
            <div class="header">
                <h1>User Management</h1>
                <div class="sort-container">
                    <form method="GET" action="">
                        <label for="sort_by">Sort By:</label>
                        <select name="sort_by" id="sort_by" onchange="this.form.submit()">
                            <option value="username" <?= $sort_by === 'username' ? 'selected' : '' ?>>Name</option>
                            <option value="email" <?= $sort_by === 'email' ? 'selected' : '' ?>>Email</option>
                            <option value="user_type" <?= $sort_by === 'user_type' ? 'selected' : '' ?>>Role</option>
                            <option value="current_time" <?= $sort_by === 'current_time' ? 'selected' : '' ?>>Created At</option>
                        </select>
                        <input type="hidden" name="order" value="<?= $order ?>">
                    </form>
                </div>
            </div>

            <a href="add_user.php" class="btn">Add User</a>

            <div class="user-table">
                <table>
                    <thead>
                        <tr>
                            <th>Sr</th>
                            <th>ID</th>
                            <th><a href="?sort_by=username&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>">Name</a></th>
                            <th><a href="?sort_by=email&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>">Email</a></th>
                            <th><a href="?sort_by=user_type&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>">Role</a></th>
                            <th><a href="?sort_by=current_time&order=<?= $order === 'ASC' ? 'DESC' : 'ASC' ?>">Created At</a></th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $serial_no = 1;
                        if ($result->num_rows > 0) {
                            while ($row = $result->fetch_assoc()) {
                                echo "<tr>
                                    <td>{$serial_no}</td>
                                    <td>{$row['id']}</td>
                                    <td>{$row['username']}</td>
                                    <td>{$row['email']}</td>
                                    <td>{$row['user_type']}</td>
                                    <td>{$row['current_time']}</td>
                                    <td class='action-buttons'>
                                        <a href='edit_user.php'?id={$row['id']}' class='edit-btn'>Edit</a>
                                        <form action='delete_user.php' method='POST' onsubmit='return confirmDelete();' style='display:inline-block;'>
                                            <input type='hidden' name='user_id' value='{$row['id']}'>
                                            <button type='submit' class='delete-btn'>Delete</button>
                                        </form>
                                    </td>
                                </tr>";
                                $serial_no++;
                            }
                        } else {
                            echo "<tr><td colspan='7' style='text-align:center;'>No users found</td></tr>";
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
  function confirmDelete() {
    return confirm("Are you sure you want to delete this user?");
  }

  document.getElementById("toggleSidebar").addEventListener("click", function () {
      const sidebar = document.querySelector('.sidebar');
      const mainContent = document.querySelector('.main-content');
      
      sidebar.classList.toggle("collapsed");
      mainContent.classList.toggle("collapsed");
  });
</script>

</body>
</html>

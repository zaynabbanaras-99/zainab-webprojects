<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Sidebar</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <style>
        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background-color: #970037;
            color: #ffffff;
            padding: 20px;
            position: fixed;
            height: 100vh;
            transition: transform 0.3s ease-in-out;
            overflow-y: auto;
            z-index: 100;
        }
        .sidebar.collapsed {
            transform: translateX(-100%);
        }
        .brand h3 {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar ul {
            list-style: none;
            padding: 0;
        }
        .sidebar ul li {
            margin: 15px 0;
        }
        .sidebar ul li a {
            color: #ffffff;
            text-decoration: none;
            padding: 10px;
            display: block;
            transition: background 0.3s;
        }
        .sidebar ul li a:hover {
            background-color: #f8d7da;
            color: #000000;
        }

        /* Responsive Styles */
        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                transform: translateY(-100%);
                position: relative;
            }
            .sidebar.collapsed {
                transform: translateY(0);
            }
        }

        /* Toggle Button for Smaller Screens */
        .toggle-button {
            display: none;
            background-color: #970037;
            color: #ffffff;
            padding: 10px;
            font-size: 20px;
            cursor: pointer;
            position: absolute;
            top: 20px;
            right: 20px;
        }
        @media (max-width: 768px) {
            .toggle-button {
                display: block;
            }
        }
    </style>
</head>
<body>

<div class="toggle-button" onclick="toggleSidebar()">
    <i class="fas fa-bars"></i>
</div>

<div class="sidebar" id="sidebar">
    <div class="brand">
        <h3>The Custom Chic</h3>
    </div>
    <ul>
    <li><a href="dashboard.php"><i class="fas fa-tachometer-alt"></i> Dashboard</a></li>
        <li><a href="manage_product.php"><i class="fas fa-tshirt"></i> Products</a></li>
        <li><a href="manage_orders.php"><i class="fas fa-box"></i> Orders</a></li>
        <li><a href="manage_user.php"><i class="fas fa-users"></i> Customers</a></li>
        <li><a href="manage_variations.php"><i class="fas fa-pencil-ruler"></i> Customizations</a></li>
        <li><a href="manage_variation_options.php"><i class="fas fa-edit"></i> Customizations available</a></li>
        <li><a href="manage_category.php"><i class="fas fa-th-list"></i> Categories</a></li>
        <li><a href="manage_user_feedback.php"><i class="fas fa-comments"></i> Feedbacks</a></li>
        <li><a href="manage_images.php"><i class="fas fa-images"></i> Product images</a></li>
        <li><a href="manage_orderline.php"><i class="fas fa-shopping-basket"></i> Orders Line</a></li>
        <li><a href="manage_faqs.php"><i class="fas fa-question-circle"></i> FAQs</a></li>
        <li><a href="manage_contacts.php"><i class="fas fa-phone-alt"></i> Contacts</a></li>
        <li><a href="manage_useraddress.php"><i class="fas fa-map-marker-alt"></i> Addresses</a></li>
        <li><a href="../log_in/sign_out.php"><i class="fas fa-sign-out-alt"></i> Sign Out</a></li>

    </ul>
</div>

<script>
    function toggleSidebar() {
        document.getElementById("sidebar").classList.toggle("collapsed");
    }
</script>

</body>
</html>

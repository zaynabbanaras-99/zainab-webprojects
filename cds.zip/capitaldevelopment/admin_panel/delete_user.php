<?php
session_start();
include('../db_con.php');

// Check if CSRF token is valid
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        die("CSRF token mismatch!");
    }

    // Check if user_id is set
    if (isset($_POST['user_id'])) {
        $user_id = intval($_POST['user_id']);  // Sanitize user input

        // Prepare DELETE query
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $user_id);

        // Execute the query
        if ($stmt->execute()) {
            // Redirect back to the user management page with success message
            header("Location: user_management.php?message=User+deleted+successfully");
            exit();
        } else {
            // Handle error if query fails
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
    }
} else {
    die("Invalid request method.");
}
?>


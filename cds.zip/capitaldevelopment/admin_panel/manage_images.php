<?php
// Database connection
include('../connects.php');

// Fetch product images data
$query = "SELECT product_id, pro_img_name FROM product_images";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Images</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }

        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            color: #970037;
            margin-bottom: 20px;
            font-weight: bold;
        }

        table {
            width: 50%;
            border-collapse: collapse;
            margin: 0 auto;
            background-color: white;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #970037;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #e1e1e1;
        }

        .category-image {
            width: 80px;
            height: 80px;
            object-fit: cover;
            border-radius: 5px;
        }

        .action-buttons {
            display: flex;
            gap: 20px;
        }

        .action-buttons button {
            padding: 8px 12px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 14px;
        }

        .update-button {
            background-color: #28a745;
            color: white;
        }

        .update-button:hover {
            background-color: #218838;
        }

        .delete-button {
            background-color: #dc3545;
            color: white;
        }

        .delete-button:hover {
            background-color: #c82333;
        }

        .add-category {
            margin-bottom: 20px;
            text-align: center;
        }

        .add-category button {
            padding: 10px 20px;
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .add-category button:hover {
            background-color: #7c002c;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <h1>Manage Images</h1>

    <!-- Add Product Button -->
    <div class="add-category">
        <button onclick="window.location.href='add_images.php'">Add Images</button>
    </div>

    <!-- Product Images Table -->
    <table>
        <thead>
            <tr>
                <th>Product ID</th>
                <th>Image</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <?php if (mysqli_num_rows($result) > 0): ?>
                <?php while ($row = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?php echo $row['product_id']; ?></td>
                        <td><img src="../images/<?php echo $row['pro_img_name']; ?>" class="category-image" alt="Product Image"></td>
                        <td class="action-buttons">
                            <!-- Update button with pro_img_id passed to update_images.php -->
                            <a href="update_images.php?product_id=<?php echo $row['product_id']; ?>">
                            <button class="update-button">Update</button>
                            </a>
                            <!-- Delete button with form submission -->
                            <form action="manage_images.php" method="post" onsubmit="return confirm('Are you sure you want to delete this image?');">
                                <input type="hidden" name="product_id" value="<?php echo $row['product_id']; ?>">
                                <button type="submit" name="delete" class="delete-button">Delete</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            <?php else: ?>
                <tr>
                    <td colspan="3" style="text-align: center;">No images found.</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>

    <?php
    // Delete functionality
    if (isset($_POST['delete'])) {
        $product_id = $_POST['product_id'];

        // Delete the image record from the database
        $delete_query = "DELETE FROM product_images WHERE product_id = $product_id";
        if (mysqli_query($conn, $delete_query)) {
            // Successfully deleted, redirect to the same page
            header("Location: manage_images.php");
            exit();
        } else {
            echo "Error deleting image: " . mysqli_error($conn);
        }
    }
    ?>
</body>
</html>

<?php
include(__DIR__ . '/../db_con.php'); // ✅ Correct path
include(__DIR__ . '/admin_side_navbar.php'); // ✅ Sidebar include
session_start();

// Initialize variables
$success = '';
$error = '';

// Handle form submission
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (isset($_POST['category_name'], $_POST['description'], $_FILES['image'])) {
        $category_name = trim($_POST['category_name']);
        $description = trim($_POST['description']);
        $image = $_FILES['image']['name'];
        $image_tmp = $_FILES['image']['tmp_name'];

        if (!empty($category_name) && !empty($description) && !empty($image)) {
            $upload_dir = __DIR__ . '/../images/';
            $image_path = $upload_dir . basename($image);

            if (move_uploaded_file($image_tmp, $image_path)) {
                $stmt = $conn->prepare("INSERT INTO product_category (category_name, description, image) VALUES (?, ?, ?)");
                $stmt->bind_param("sss", $category_name, $description, $image);

                if ($stmt->execute()) {
                    $success = "Category added successfully.";
                } else {
                    $error = "Database error: " . $stmt->error;
                }
            } else {
                $error = "Failed to upload image.";
            }
        } else {
            $error = "Please fill in all fields.";
        }
    } else {
        $error = "Invalid form submission.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Add Category</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .main-content {
            margin-left: 260px;
            padding: 40px;
        }
        .container {
            background-color: #fff;
            padding: 30px;
            max-width: 600px;
            margin: auto;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #970037;
            margin-bottom: 20px;
            text-align: center;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin: 10px 0 5px;
            font-weight: bold;
        }
        input[type="text"], textarea, input[type="file"] {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin-bottom: 15px;
            font-size: 14px;
        }
        button {
            background-color: #970037;
            color: white;
            border: none;
            padding: 10px;
            font-size: 15px;
            border-radius: 5px;
            cursor: pointer;
            width: 150px;
            align-self: center;
        }
        button:hover {
            background-color: #85002a;
        }
        .message {
            text-align: center;
            margin-top: 15px;
            font-size: 14px;
        }
        .message.success {
            color: green;
        }
        .message.error {
            color: red;
        }
    </style>
</head>
<body>
<div class="main-content">
    <div class="container">
        <h1>Add Category</h1>

        <?php if ($success): ?>
            <div class="message success"><?= $success ?></div>
        <?php elseif ($error): ?>
            <div class="message error"><?= $error ?></div>
        <?php endif; ?>

        <form action="add_category.php" method="post" enctype="multipart/form-data">
            <label for="category_name">Category Name:</label>
            <input type="text" id="category_name" name="category_name" required>

            <label for="description">Description:</label>
            <textarea id="description" name="description" rows="4" required></textarea>

            <label for="image">Upload Image:</label>
            <input type="file" id="image" name="image" accept="image/*" required>

            <button type="submit">Add Category</button>
        </form>
    </div>
</div>
</body>
</html>

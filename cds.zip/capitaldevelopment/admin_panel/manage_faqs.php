<?php
include('../connects.php');
$query = "SELECT * FROM faq";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage FAQs</title>
    <style>
                      .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
    text-align: left;
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding: 20px;
        }

        .container {
            width: 80%;
            margin: 0 auto;
            text-align: center;
        }

        h1 {
            color: #970037;
            margin-bottom: 20px;
        }

        table {
            width: 60%;
            border-collapse: collapse;
            margin: 0 auto;
            margin-bottom: 20px;
            border: 2px solid black; /* Outer border color set to black */
        }

        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }

        th {
            background-color: #970037;
            color: white;
            text-align: center; /* Centered column names */
        }

        td {
            background-color: white;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .action-buttons {
            display: flex;
            gap: 10px; /* Gap between buttons */
            justify-content: center; /* Center the buttons */
        }
        .add-faqs button {
            background-color: #970037;
            margin-bottom: 20px;
        }
        .add-faqs {
            text-align: center;
            color: white;
        }
        button {
            padding: 5px 10px;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .update-button {
            padding: 5px 10px;
            background-color: #28a745; /* Green for update button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .update-button:hover {
            background-color: #218838;
        }

        .delete-button {
            padding: 5px 10px;
            background-color: #dc3545; /* Red for delete button */
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }

        .delete-button:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>

<div class="container">
    <h1>Manage FAQs</h1>
    <div class="add-faqs">
        <form action="add_faqs.php" method="post">
            <button type="submit">Add FAQs</button>
        </form>
    </div>
    <table>
        <tr>
            <th>Serial No</th>
            <th>Question</th>
            <th>Answer</th>
            <th>Date & Time</th>
            <th>Action</th>
        </tr>
        <?php 
        $serial = 0;
        while ($row = mysqli_fetch_assoc($result)) {
            $serial++;
            $faqid = $row['faq_id'];
            $q = $row['question'];
            $ans = $row['answer'];
            $dt = $row['faq_dt'];
        ?>
        <tr>
            <td><?php echo $serial ?></td>
            <td><?php echo $q ?></td>
            <td><?php echo $ans ?></td>
            <td><?php echo $dt ?></td>
            <td class="action-buttons">
            <form action='update_faqs.php' method='get' style='display:inline;'>
            <input type='hidden' name='faq_id' value='<?php echo $faqid; ?>'>
            <button type='submit' class='update-button'>Update</button>
            </form>

                <form action="" method="get" onsubmit="return confirm('Are you sure you want to delete this FAQ?');">
                    <input type="hidden" name="faq_id" value="<?php echo $faqid; ?>">
                    <button type="submit" name="delete" class="delete-button">Delete</button>
                </form>
            </td>
        </tr>
        <?php
        }
        ?>
    </table>
</div>

</body>
</html>

<?php
if (isset($_GET['faq_id'])) {
    $del_id = $_GET['faq_id'];
    $del_q = mysqli_query($conn, "DELETE FROM faq WHERE faq_id='$del_id'");
    if ($del_q) {
        header('location:manage_FAQs.php');
    } else {
        echo "Data is not deleted";
    }
}
?>


<?php
include('../connects.php'); // Database connection

// Fetch all users from the database
$sql = "SELECT user_id, user_name, user_email, user_password, user_type, account_creation_dt FROM user";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
                .sidebar {
    position: fixed; /* Fix the sidebar on the left */
    top: 0;
    left: 0;
    width: 250px;  /* Set the width of the sidebar */
    height: 100%;  /* Sidebar should span the full height */
    background-color: #fff;
    box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
    padding: 20px;
    z-index: 100; /* Ensure it stays on top of other content */
}
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

       
        h1 {
            text-align: center;
            color: #960037;
            margin-top: 40px; /* Add margin-top to push the heading down */
        }

        table {
            width: 60%;
            margin-right: 20px;
            border-collapse: collapse;
            margin: 0px auto;
            font-size: 0.8em; 
            border: 2px solid black;
            margin-right: 270px; 
        }

        th, td {
            padding: 12px;
            text-align: left;
            border: 1px solid #ddd;
        }

        th {
            background-color: #960037;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        .action-btn {
            display: inline-block;
            padding: 8px 12px;
            color: white;
            border-radius: 4px;
            text-decoration: none;
            margin-right: 5px;
        }

        .edit-btn {
            background-color: #28a745; /* Green for Edit */
        }

        .delete-btn {
            background-color: #dc3545; /* Red for Delete */
        }

        .edit-btn:hover {
            background-color: #218838;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>

   
        <h1>Manage Users</h1>
        <table>
            <thead>
                <tr>
                    <th>#Serial.no</th>
                    <th>User Name</th>
                    <th>Email</th>
                    <th>Password</th>
                    <th>User Type</th>
                    <th>Account Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php
                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>";
                        echo "<td>" . $row['user_id'] . "</td>";
                        echo "<td>" . $row['user_name'] . "</td>";
                        echo "<td>" . $row['user_email'] . "</td>";
                        echo "<td>" . $row['user_password'] . "</td>";
                        echo "<td>" . $row['user_type'] . "</td>";
                        echo "<td>" . $row['account_creation_dt'] . "</td>";
                        echo "<td>";
                        echo "<a href='update_user.php?id=" . $row['user_id'] . "' class='action-btn edit-btn'>Edit</a>";
                        echo "<a href='delete_user.php?id=" . $row['user_id'] . "' class='action-btn delete-btn'>Delete</a>";
                        echo "</td>";
                        echo "</tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No users found</td></tr>";
                }
                ?>
            </tbody>
        </table>

</body>
</html>

<?php
mysqli_close($conn); // Close database connection
?>

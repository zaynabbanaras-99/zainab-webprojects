<?php
include('../db_con.php'); // Adjust path as needed

// ✅ Handle delete BEFORE any HTML
if (isset($_POST['delete'])) {
    $feedback_id = $_POST['feedback_id'];
    $delete_query = "DELETE FROM user_feedback WHERE feedback_id = $feedback_id";
    mysqli_query($conn, $delete_query);
    header("Location: manage_user_feedback.php");
    exit();
}

// ✅ Fetch feedback data
$query = "SELECT * FROM user_feedback";
$result = mysqli_query($conn, $query);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Feedback</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
            margin: 0;
            padding-left: 270px;
        }
        .sidebar {
            position: fixed;
            top: 0; left: 0;
            width: 250px; height: 100%;
            background: #fff;
            box-shadow: 2px 0 5px rgba(0,0,0,0.1);
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #970037;
            margin-top: 30px;
        }
        table {
            width: 80%;
            margin: 30px auto;
            border-collapse: collapse;
            background-color: white;
            border: 2px solid black;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
        }
        th, td {
            padding: 12px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: #970037;
            color: white;
        }
        tr:nth-child(even) { background-color: #f2f2f2; }
        tr:hover { background-color: #f1f1f1; }
        .action-buttons { display: flex; gap: 10px; }
        .update-button, .delete-button {
            padding: 5px 10px;
            border: none; border-radius: 4px;
            color: white; cursor: pointer;
        }
        .update-button { background-color: #28a745; }
        .update-button:hover { background-color: #218838; }
        .delete-button { background-color: #dc3545; }
        .delete-button:hover { background-color: #c82333; }
    </style>
</head>
<body>
<?php include('admin_side_navbar.php'); ?>

<h1>User Feedback</h1>

<table>
    <tr>
        <th>Feedback ID</th>
        <th>User ID</th>
        <th>Comment</th>
        <th>Date & Time</th>
        <th>Actions</th>
    </tr>

    <?php
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<tr>
                    <td>{$row['feedback_id']}</td>
                   
                    <td>{$row['comment']}</td>
                    <td>{$row['date_time']}</td>
                    <td class='action-buttons'>
                        <form action='update_feedback.php' method='get'>
                            <input type='hidden' name='feedback_id' value='{$row['feedback_id']}'>
                            <button type='submit' class='update-button'>Update</button>
                        </form>
                        <form action='' method='post' onsubmit='return confirm(\"Are you sure you want to delete this feedback?\");'>
                            <input type='hidden' name='feedback_id' value='{$row['feedback_id']}'>
                            <button type='submit' name='delete' class='delete-button'>Delete</button>
                        </form>
                    </td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='5' style='text-align:center;'>No feedback found.</td></tr>";
    }
    ?>
</table>
</body>
</html>

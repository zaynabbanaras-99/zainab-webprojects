<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Add Variation Options</title>
    <style>
        .sidebar {
            position: fixed; /* Fix the sidebar on the left */
            top: 0;
            left: 0;
            width: 250px;  /* Set the width of the sidebar */
            height: 100%;  /* Sidebar should span the full height */
            background-color: #fff;
            box-shadow: 2px 0 5px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100; /* Ensure it stays on top of other content */
            text-align: left;
        }
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .form-container {
            background-color: #fff;
            padding: 40px;
            border: 1px solid #ddd;
            width: 600px;
            min-height: 500px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
            text-align: center;
        }
        h2 {
            color: #970037;
            margin-bottom: 20px;
        }
        input, select, button {
            width: 100%;
            padding: 12px;
            margin-bottom: 15px;
            border: 1px solid #ddd;
            border-radius: 5px;
        }
        button {
            width: 50%;
            background-color: #970037;
            color: white;
            border: none;
            padding: 12px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }
        button:hover {
            background-color: #70002a;
        }
        input[type="file"] {
            padding: 5px;
        }
        .message {
            margin-top: 20px;
            padding: 15px;
            background-color: #d4edda;
            color: #155724;
            border: 1px solid #c3e6cb;
            border-radius: 5px;
            display: inline-block;
        }
        .error {
            background-color: #f8d7da;
            color: #721c24;
            border-color: #f5c6cb;
        }
        .message p {
            margin: 0;
        }
    </style>
</head>
<body>
<?php include('sidebar.php'); ?>
    <div class="form-container">
        <h2>Add Variation Options</h2>
        <form method="POST" action="" enctype="multipart/form-data">
            <input type="text" name="variation_type" placeholder="Variation Type" required>
            <input type="file" name="option_image" required>
            <input type="text" name="variation_id" placeholder="Variation ID" required>
            <input type="text" name="additional_cost" placeholder="Additional Cost" required>
            <textarea name="description" placeholder="Description" required></textarea>
            <input type="text" name="product_id" placeholder="Product ID" required>
            <button type="submit" name="submit">Add Variation Option</button>
        </form>
        <?php
        include('../connects.php');

        if (isset($_POST['submit'])) {
            $variation_type = $_POST['variation_type'];
            $option_image = $_FILES['option_image']['name'];
            $variation_id = $_POST['variation_id'];
            $additional_cost = $_POST['additional_cost'];
            $description = $_POST['description'];
            $product_id = $_POST['product_id'];

            // Move uploaded file
            move_uploaded_file($_FILES['option_image']['tmp_name'], "uploads/" . $option_image);

            // Corrected Insert query with backticks around table name
            $sql = "INSERT INTO `variation-options` (variation_type, option_image, variation_id, additional_cost, description, product_id) VALUES ('$variation_type', '$option_image', '$variation_id', '$additional_cost', '$description', '$product_id')";

            if ($conn->query($sql) === TRUE) {
                echo "<div class='message'>New variation option added successfully!</div>";
            } else {
                echo "<div class='error'>Error: " . $sql . "<br>" . $conn->error . "</div>";
            }

            $conn->close();
        }
        ?>
    </div>
</body>
</html>

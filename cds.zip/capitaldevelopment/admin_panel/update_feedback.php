<?php
include('../connects.php'); // Include your database connection file

// Check if the feedback ID is passed via GET
if (isset($_GET['feedback_id'])) {
    $feedback_id = $_GET['feedback_id'];

    // Fetch the feedback data from the database
    $result = mysqli_query($conn, "SELECT * FROM user_feedback WHERE feedback_id = $feedback_id");

    // Check if the feedback exists
    if ($result && mysqli_num_rows($result) > 0) {
        $feedback = mysqli_fetch_assoc($result); // Fetch feedback data into the $feedback array
    } else {
        // Redirect if feedback does not exist
        header("Location: manage_user_feedback.php");
        exit();
    }
} else {
    // Redirect if no feedback ID is provided
    header("Location: manage_user_feedback.php");
    exit();
}

// Handle form submission for updating the feedback comment
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $comment = mysqli_real_escape_string($conn, $_POST['comment']); // Sanitize user input

    // Update feedback comment in the database
    $update_query = "UPDATE user_feedback SET comment = '$comment' WHERE feedback_id = $feedback_id";

    if (mysqli_query($conn, $update_query)) {
        // Redirect to the user feedback page after update
        header("Location: manage_user_feedback.php");
        exit();
    } else {
        $error_message = "Error updating feedback: " . mysqli_error($conn); // Capture error if the update fails
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Feedback</title>
    <style>
        * {
            box-sizing: border-box;
        }

        body {
            font-family: "Poppins", sans-serif;
            background: linear-gradient(135deg, #f9f9f9, #f4f4f4);
            margin: 0;
            padding: 0;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar (keep admin style) */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 250px;
            height: 100%;
            background-color: #ffffff;
            box-shadow: 2px 0 8px rgba(0, 0, 0, 0.1);
            padding: 20px;
            z-index: 100;
            transition: all 0.3s ease-in-out;
        }

        .sidebar:hover {
            box-shadow: 3px 0 12px rgba(0, 0, 0, 0.2);
        }

        /* Main Content */
        .main-content {
            margin-left: 270px;
            width: calc(100% - 270px);
            display: flex;
            justify-content: center;
            align-items: center;
            padding: 50px 20px;
        }

        .container {
            width: 100%;
            max-width: 600px;
            background: #fff;
            padding: 40px 50px;
            border-radius: 16px;
            box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
            animation: fadeIn 0.8s ease-in-out;
        }

        @keyframes fadeIn {
            from {
                opacity: 0;
                transform: translateY(20px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        h1 {
            color: #970037;
            text-align: center;
            margin-bottom: 25px;
            font-size: 28px;
            font-weight: 700;
            letter-spacing: 1px;
            position: relative;
        }

        h1::after {
            content: "";
            position: absolute;
            width: 60px;
            height: 3px;
            background: #970037;
            bottom: -10px;
            left: 50%;
            transform: translateX(-50%);
            border-radius: 3px;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            font-weight: 600;
            color: #333;
            margin-bottom: 6px;
            font-size: 16px;
        }

        textarea {
            width: 100%;
            padding: 12px 14px;
            border: 1px solid #ccc;
            border-radius: 8px;
            font-size: 15px;
            min-height: 140px;
            resize: vertical;
            transition: all 0.3s ease;
        }

        textarea:focus {
            outline: none;
            border-color: #970037;
            box-shadow: 0 0 5px rgba(151, 0, 55, 0.3);
        }

        button {
            background-color: #970037;
            color: white;
            border: none;
            border-radius: 8px;
            padding: 12px;
            cursor: pointer;
            font-size: 16px;
            font-weight: 600;
            width: 100%;
            margin-top: 10px;
            transition: all 0.3s ease;
        }

        button:hover {
            background-color: #7c002e;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(151, 0, 55, 0.3);
        }

        .message {
            text-align: center;
            font-size: 15px;
            margin-bottom: 15px;
            padding: 10px;
            border-radius: 5px;
            animation: fadeIn 0.6s ease-in-out;
        }

        .message.success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #a5d6a7;
        }

        .message.error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ef9a9a;
        }

        @media (max-width: 768px) {
            .sidebar {
                width: 100%;
                height: auto;
                position: relative;
                box-shadow: none;
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                padding: 20px;
            }

            .container {
                padding: 25px;
            }
        }
    </style>
</head>
<body>

<?php include('sidebar.php'); ?>

<div class="main-content">
    <div class="container">
        <h1>Update Feedback</h1>

        <!-- Display success or error message -->
        <?php if (isset($error_message)): ?>
            <div class="message error"><?php echo $error_message; ?></div>
        <?php elseif ($_SERVER['REQUEST_METHOD'] == 'POST'): ?>
            <div class="message success">✅ Feedback updated successfully!</div>
        <?php endif; ?>

        <!-- Feedback update form -->
        <form action="update_feedback.php?feedback_id=<?php echo $feedback['feedback_id']; ?>" method="POST">
            <label for="comment">Feedback Comment</label>
            <textarea name="comment" id="comment" rows="5" required><?php echo $feedback['comment']; ?></textarea>

            <button type="submit">💾 Update Feedback</button>
        </form>
    </div>
</div>

</body>
</html>
